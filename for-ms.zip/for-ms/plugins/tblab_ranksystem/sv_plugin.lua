/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

local PLUGIN = PLUGIN

-- function PLUGIN:CompleteActivity(ply, act)
	-- local char = ply:getChar()
	-- local money = char:getMoney()
	-- char:setMoney(money + PLUGIN.activities[act].revard)
	-- ply:notify("Поручение выполнено, вы получили: ".. PLUGIN.activities[act].revard .. "$")
	-- char:setData("onWork", false)
-- end
function PLUGIN:RankUp(client, target)
	local CTchar,TTchar = client:getChar(),target:getChar()
	local CTfaction,TTfaction = CTchar:getFaction(), TTchar:getFaction()
	local CTrank,TTrank = CTchar:getData("rank", 1), TTchar:getData("rank", 1)
	local CTFdata,TTFdata = nut.faction.indices[CTfaction],nut.faction.indices[TTfaction]
	if (CTFdata.ranktable or "Ranksmain") == (TTFdata.ranktable or "Ranksmain") then 
		local RTABLE = SCHEMA.RanksData[CTFdata.ranktable]
		if TTrank >= CTrank then return false end
		if RTABLE.canup[CTrank] > TTrank then
			TTrank = math.Clamp(TTrank + 1,1,#RTABLE.ranks)
			TTchar:setData("rank",TTrank)
			target:setNetVar("rank",  TTrank)
			client:notify("Вы повысили ".. target:Name() .. " до звания " .. RTABLE.translate[TTrank])
			target:notify(client:Name() .. " повысил вас до звания ".. RTABLE.translate[TTrank])
		else
			client:notify("Нет доступа повышать выше")
		end
	end
end	

function PLUGIN:RankDown(client, target)
	local CTchar,TTchar = client:getChar(),target:getChar()
	local CTfaction,TTfaction = CTchar:getFaction(), TTchar:getFaction()
	local CTrank,TTrank = CTchar:getData("rank", 1), TTchar:getData("rank", 1)
	local CTFdata,TTFdata = nut.faction.indices[CTfaction],nut.faction.indices[TTfaction]
	if (CTFdata.ranktable or "Ranksmain") == (TTFdata.ranktable or "Ranksmain") then 
		local RTABLE = SCHEMA.RanksData[CTFdata.ranktable]
		if TTrank >= CTrank then return false end
		if RTABLE.canup[CTrank] >= TTrank then
			TTrank =  math.Clamp(TTrank - 1,1,#RTABLE.ranks)
			TTchar:setData("rank",TTrank)
			target:setNetVar("rank",  TTrank)
			client:notify("Вы понизили ".. target:Name() .. " до звания " .. RTABLE.translate[TTrank])
			target:notify(client:Name() .. " понизил вас до звания ".. RTABLE.translate[TTrank])
		else
			client:notify("Нет доступа")
		end
	end
end