/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2026 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

PLUGIN.name = "Rank System"
PLUGIN.author = "Tium (discord: _tium_)"
PLUGIN.desc = "Плагин позволяет добавить на сервер ранговую систему с повышениеми. Все данные прописываются в sv_ranks.lua"

local PLUGIN = PLUGIN
--------------Включения-------------------
nut.util.include("sv_plugin.lua")
------------------------------------------
local ranktable = SCHEMA.RanksData

function PLUGIN:PlayerSpawn(client)
	client:AllowFlashlight(true)
	local character = client:getChar()
	if character then
		local FactionRanksType = nut.faction.indices[character:getFaction()].ranktable or "Ranksmain"
		local RT = SCHEMA.RanksData[FactionRanksType]
		client:setNetVar("rank",  character:getData("rank",1))
	end
end

nut.command.add("ranksup", {
	syntax = "<string name>",
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(player, arguments[1])
		if (IsValid(target)) then
			PLUGIN:RankUp(client, target)
		end
	end
})

nut.command.add("ranksdown", {
	syntax = "<string name>",
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(player, arguments[1])
		if (IsValid(target)) then
			PLUGIN:RankDown(client, target)
		end
	end
})

nut.command.add("arank", {
	adminOnly = true,
	syntax = "<sting name> <string number>",
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(player, arguments[1])
		if (IsValid(target)) then
			local chartarget = target:getChar()
			local ranknum = tonumber(arguments[2])
			chartarget:setData("rank", ranknum)
			target:setNetVar("rank", ranknum )
			client:notify("Ранг для (" .. chartarget:getName() .. ") установлен на " .. ranknum .. ".")
		end
	end
})