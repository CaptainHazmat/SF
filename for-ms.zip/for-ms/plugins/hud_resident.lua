/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2024 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/



PLUGIN.name = "Худ для всех параметров"
PLUGIN.author = "Tium"
PLUGIN.desc = "."

local g_down = 0
local maskdelay = 0
local tiedelay = 0
local item = false
local item2 = false
local item3 = false
local bindPressed = false
local bindPressedap = false
local bindPressednvg = false
local bp1 = false
local Tips = {
	["I"] = "Инвентарь",
	["TAB"] = "Список игроков",
	["F1"] = "Меню взаимодействий",
	["F3"] = "Третье лицо",
	["F6"] = "Вкл/Выкл подсказки",
	["F"] = "Фонарик",
	["CTRL x 2"] = "Лечь",
	["E на Игрока"] = "Взаимодействие",
	["СКМ"] = "Информация о игроке|осмотреться",
	["G"] = "Пополнение пластин",
}
local WeaponTips = {
	["E+Скрол"] = "Переключить прицел",
	["R"] = "Перезарядка",
	["E+ПКМ"] = "Переключение подствольника",
	["E+ЛКМ"] = "Ближний бой (Если есть)",
	--[""] = "",
	
}

if CLIENT then
	NUT_SHOW_TIPS = CreateClientConVar("nut_showtips", 0, true, true)
	
	local function addNVGanel(frame)
		local panel = frame:Add("ControlPanel")
			panel:SetName("Thirdperson")
			panel:SetSize(120, 90)
			panel:AddControl("Numpad", {
				Label = "Установить кнопку",
				Command = "nvg_on"
			})
	end
	netstream.Hook("nutNVGManager", function()
		frame = vgui.Create("DFrame")
		frame:SetSize(150, 150)
		frame:Center()
		frame:MakePopup()
		frame:ShowCloseButton( true )
		frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
				draw.RoundedBox( 2, 0, 0, w, h, Color( 255, 255, 255, 255 ) ) -- Draw a red box instead of the frame
				draw.RoundedBox( 2, 0, 0, 410, 30, Color( 255, 0, 0, 255 ) )
			end
		frame:SetTitle("Выбор кнопки NVG")

		frame.menu = frame:Add("PanelList")
		frame.menu:Dock(FILL)
		frame.menu:DockMargin(5, 5, 5, 5)
		frame.menu:SetSpacing(2)
		frame.menu:SetPadding(2)
		frame.menu:EnableVerticalScrollbar()

		addNVGanel(frame.menu)
	end)

	function PLUGIN:ShouldBarDraw()
		return false
	end

	function PLUGIN:HUDPaint()
		if LocalPlayer():getChar() != nil then
			local ply = LocalPlayer()
			local char = ply:getChar()
			-----------часы-------------
			--local angleH,angleM = (-30 * tonumber(os.date( "%I" ))) - (0.5 * tonumber(os.date( "%M" ))), -6 * tonumber(os.date( "%M" ))
			
			--draw.SimpleText(char:getData("CharSalary",0), "Default", ScrW()*0.135, ScrH()*0.04, Color( 255, 104, 86, 255 ),0,0)
			--draw.SimpleText(timer.Exists( "nutSalary1"..LocalPlayer():UniqueID() ), "Default", ScrW()*0.135, ScrH()*0.05, Color( 255, 104, 86, 255 ),0,0)
			--draw.SimpleText(timer.Exists( "nutSalary"..LocalPlayer():UniqueID() ), "Default", ScrW()*0.135, ScrH()*0.06, Color( 255, 104, 86, 255 ),0,0)
			--"nutSalary"..client:UniqueID()  timer.TimeLeft( "nutSalary1"..client:UniqueID() )
			-- surface.SetDrawColor(255, 255, 255)
			-- surface.SetMaterial(Material("hud/clock.png")) 
			-- surface.DrawTexturedRect(0, 0, 128, 128)
			
			-- surface.SetDrawColor(255, 255, 255)
			-- surface.SetMaterial(Material("hud/clock_h.png")) 
			-- surface.DrawTexturedRectRotated(64, 64, 128, 128, angleH)
			
			-- surface.SetDrawColor(255, 255, 255)
			-- surface.SetMaterial(Material("hud/clock_m.png")) 
			-- surface.DrawTexturedRectRotated(64, 64, 128, 128, angleM)
			------------------------
			
			if (system.IsLinux() or system.HasFocus()) and !vgui.GetKeyboardFocus() and !gui.IsGameUIVisible() and !gui.IsConsoleVisible() then
				local bindKey = 97
				
				if input.IsKeyDown(bindKey) then
					bp1 = true
				else
					if bp1 then
						if NUT_SHOW_TIPS:GetBool() == true then
							RunConsoleCommand("nut_showtips", "0")
						else
							RunConsoleCommand("nut_showtips", "1")
						end
						bp1 = false
					end
				end
			end
			local x, y = 10, 0
			if NUT_SHOW_TIPS:GetBool() == true then
				-- local y2 = 200
				-- for k,v in pairs(LocalPlayer():getChar():getData("Work")) do
					-- draw.DrawText(k .. " - " .. tostring(v), "menu_22", 500, y2, Color(255, 255, 255, 210), TEXT_ALIGN_LEFT)
					-- y2 = y2 + 22
				-- end
				
				for k,v in pairs(Tips) do
					draw.DrawText(k .. " - " .. v, "menu_22", x, y, Color(255, 255, 255, 210), TEXT_ALIGN_LEFT)
					y = y + 22
				end
				
				local weapon = LocalPlayer():GetActiveWeapon()
				if weapon.ARC9 then
					y = y + 22
					local firemode = input.LookupBinding("+zoom") or false
					if !firemode then draw.DrawText("Назначте клавишу Приближение (костюм)", "menu_22", x, y , Color(255, 255, 255, 210), TEXT_ALIGN_LEFT) else
						draw.DrawText(firemode .. " - Переключение режима огня", "menu_22", x, y , Color(255, 255, 255, 210), TEXT_ALIGN_LEFT)
						y = y + 22
						draw.DrawText(firemode .. " + " .. input.LookupBinding("+use") ..  " - Переключение режима огня", "menu_22", x, y , Color(255, 255, 255, 210), TEXT_ALIGN_LEFT)
						y = y + 22
					end	
					for k,v in pairs(WeaponTips) do
						draw.DrawText(k .. " - " .. v, "menu_22", x, y, Color(255, 255, 255, 210), TEXT_ALIGN_LEFT)
						y = y + 22
					end
				end
			end
			
			local inv = LocalPlayer():getChar():getInv()
			
			if inv:hasItem('tie') and (nut.faction.indices[LocalPlayer():getChar():getFaction()].typefact == "USS") then
				item2 = LocalPlayer():getChar():getInv():hasItem('tie')
				
				if NUT_SHOW_TIPS:GetBool() == true then 
					draw.DrawText("H - Связать", "Roh15", x, y, Color(255, 255, 255, 210), TEXT_ALIGN_CENTER) 
					y = y + 22
				end
			end
			
			if LocalPlayer():getChar():getInv():hasItem('nw1') or LocalPlayer():getChar():getInv():hasItem('nw2') or LocalPlayer():getChar():getInv():hasItem("nw3") or LocalPlayer():getChar():getInv():hasItem("nw4") or LocalPlayer():getChar():getInv():hasItem("nw5") or LocalPlayer():getChar():getInv():hasItem("nw6") then
				item3 = LocalPlayer():getChar():getInv():hasItem('nw1') or LocalPlayer():getChar():getInv():hasItem('nw2') or LocalPlayer():getChar():getInv():hasItem("nw3") or LocalPlayer():getChar():getInv():hasItem("nw4") or LocalPlayer():getChar():getInv():hasItem("nw5") or LocalPlayer():getChar():getInv():hasItem("nw6")
				if LocalPlayer():GetNWInt("nvg") != 0 then
					
					
					if NUT_SHOW_TIPS:GetBool() == true then 
						draw.DrawText(input.GetKeyName(22) .. " - Очки", "menu_22", x, y, Color(255, 255, 255, 210), TEXT_ALIGN_LEFT)
						y = y + 22
					end
				end
			end
			
			if input.IsKeyDown(KEY_G) and (item != false) and (maskdelay < CurTime()) and !LocalPlayer():getNetVar("typing") then
				g_down = g_down + 1
				if g_down > 25 and maskdelay < CurTime() then
					if item:getData("equip") == true then
						netstream.Start("invAct", "EquipUn", item.id, LocalPlayer():getChar():getInv():getID())
					elseif item:getData("equip") == false then
						netstream.Start("invAct", "Equip", item.id, LocalPlayer():getChar():getInv():getID()) 
					end
					g_down = 0
					maskdelay = CurTime() + 2
				end
			end
			
			if input.IsKeyDown(KEY_H) and (item2 != false) and !LocalPlayer():getNetVar("typing") and (nut.faction.indices[LocalPlayer():Team()].typefact == "USS") and (maskdelay < CurTime()) then
				g_down = g_down + 1
				if g_down > 25 then
					netstream.Start("invAct", "Use", item2.id, LocalPlayer():getChar():getInv():getID())
					g_down = 0
					maskdelay = CurTime() + 5
				end
			end
			
			
			
			if (system.IsLinux() or system.HasFocus()) and !vgui.GetKeyboardFocus() and !gui.IsGameUIVisible() and !gui.IsConsoleVisible() and item3 then
				local bindKey = 22
				
				if input.IsKeyDown(bindKey) then
					bindPressednvg = true
				else
					if bindPressednvg then
						LocalPlayer():ConCommand("arc_vm_nvg")
						bindPressednvg = false
					end
				end
			end
			
			if (system.IsLinux() or system.HasFocus()) and !vgui.GetKeyboardFocus() and !gui.IsGameUIVisible() and !gui.IsConsoleVisible() then
				local bindKey = 17
				
				-- if input.IsKeyDown(bindKey) then
					
				-- end
				if input.IsKeyDown(bindKey) then
					bindPressedap = true
				else
					if bindPressedap then
						LocalPlayer():ConCommand("+armorplate")
						bindPressedap = false
					end
				end
			end
			
			if (system.IsLinux() or system.HasFocus()) and !vgui.GetKeyboardFocus() and !gui.IsGameUIVisible() and !gui.IsConsoleVisible() then
				local bindKey = 94
				
				if input.IsKeyDown(bindKey) then
					bindPressed = true
				else
					if bindPressed then
						LocalPlayer():ConCommand("simple_thirdperson_enable_toggle")
						bindPressed = false
					end
				end
			end
			
			-- draw.DrawText("•", "nutSmallFont", ScrW() * 0.5, ScrH()*0.5, Color(255, 255, 255, 210), TEXT_ALIGN_CENTER)
		end
	end
	
	PLUGIN.pressed = false

	function PLUGIN:PreRender()

		if !LocalPlayer():getChar() and IsValid(nut.gui.char) then return end

		if input.IsKeyDown(KEY_ESCAPE) then
			gui.HideGameUI()
			self.pressed = true
		end

		if !input.IsKeyDown(KEY_ESCAPE) and self.pressed then
			if IsValid(nut.gui.char) then 
				nut.gui.char:Remove()
				self.pressed = false
			else
				gui.HideGameUI()
				local valid = false
				self.pressed = false

				for k,v in pairs(nut.gui) do
					if IsValid(k) then
						k:Remove()
						valid = true
					end
				end

				if !valid then
					vgui.Create("nutCharMenu")
				end
			end
			
		end
	end
	
end

local helm0 = { -- сток
	["$pp_colour_addr"] = 0.05,
	["$pp_colour_addg"] = 0.01,
	["$pp_colour_addb"] = 0.01,
	["$pp_colour_brightness"] = 1,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 0.7,
	["$pp_colour_mulr"] = 1.1,
	["$pp_colour_mulg"] = 1.1,
	["$pp_colour_mulb"] = 0.9,
}

local helm1 = { -- uss
	["$pp_colour_addr"] = 0.45,
	["$pp_colour_addg"] = -0.10,
	["$pp_colour_addb"] = -0.05,
	["$pp_colour_brightness"] = -0.56,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 1,
	["$pp_colour_mulr"] = 0.2,
	["$pp_colour_mulg"] = 0.3,
	["$pp_colour_mulb"] = 1,
}

local helm2 = { --ubcs
	["$pp_colour_addr"] = -0.11,
	["$pp_colour_addg"] = -0.07,
	["$pp_colour_addb"] = 0.10,
	["$pp_colour_brightness"] = -0.15,
	["$pp_colour_contrast"] = 0.9,
	["$pp_colour_colour"] = 0.9,
	["$pp_colour_mulr"] = 0.2,
	["$pp_colour_mulg"] = 0.3,
	["$pp_colour_mulb"] = 1,
}

-- hook.Add( "RenderScreenspaceEffects", "colloreffect", function()
	-- local ply = LocalPlayer()
	-- local tox = LocalPlayer():getLocalVar("toxic",0)
	-- local Mtype = "helm" .. LocalPlayer():getLocalVar("MaskType",0)
	-- local toxmul = tox/100
	-- -- if  Mtype == "helm1" then -- uss
		-- -- helm1["$pp_colour_brightness"] = -0.56 - tox/400
		-- -- DrawColorModify( helm1 )
		-- -- DrawMotionBlur( 0.4*toxmul, 0.8*toxmul, 0.05*toxmul )
	-- -- elseif Mtype == "helm0" then --Сток
		-- helm0["$pp_colour_brightness"] =  -0.06 - tox/200
		-- DrawColorModify( helm0 )
		-- DrawMotionBlur( 0.4*toxmul, 0.8*toxmul, 0.05*toxmul )
	-- -- elseif Mtype == "helm2" then --ubcs
		-- -- helm2["$pp_colour_brightness"] =  -0.15 - tox/200
		-- -- DrawColorModify( helm2 )
		-- -- DrawMotionBlur( 0.4*toxmul, 0.8*toxmul, 0.05*toxmul )
	-- -- end
-- end )

