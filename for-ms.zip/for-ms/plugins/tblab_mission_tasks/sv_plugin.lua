/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/
local PLUGIN = PLUGIN
Mission = Mission or {}
Mission.data = Mission.data or {}
Mission.data.tasks = Mission.data.tasks or {} 
Mission.data.name = Mission.data.name or "Нет Заданий"
Mission.data.failed = Mission.data.failed or 0
function Mission:UpdateClients()
	if self.data == {} then return false end
	for k,v in pairs (player.GetAll()) do
		net.Start("UpdateMissionTasks")
		net.WriteTable(self.data)
		net.Send(v)
	end
end

function Mission:CheckStatus()
	local total = 0
	for k,v in pairs (self.data.tasks) do
		if v.progress == v.progressneeded then
			total = 1
		else
			total = 0
		end	
	end
	Mission.data.failed = total
	Mission:UpdateClients()
end

function Mission:CompleteTask(task)
	self.data.tasks[task].progress = self.data.tasks[task].progressneeded
	Mission:UpdateClients()
end

function Mission:CompleteAlltasks()
	for k,v in pairs(self.data.tasks) do
		v.progress = v.progressneeded
	end
	Mission.data.failed = 1
	Mission:UpdateClients()
end

function Mission:EditName(task, name)
	self.data.tasks[task].name = name
	Mission:UpdateClients()
end

function Mission:EditPNeeded(task, num)
	self.data.tasks[task].progressneeded = num
	if num < self.data.tasks[task].progress then Mission:GiveProgress(task, 0) 
	else Mission:UpdateClients() end
end

function Mission:GiveProgress(task, amount)
	local progress = self.data.tasks[ task ].progress or 0
	if amount then
		self.data.tasks[ task ].progress = math.Clamp(progress + amount, 0, self.data.tasks[ task ].progressneeded)
	else
		self.data.tasks[ task ].progress = math.Clamp(progress + 1, 0, self.data.tasks[ task ].progressneeded)
	end
	Mission:CheckStatus()
	Mission:UpdateClients()
end

function Mission:TakeProgress(task, amount)
	local progress = self.data.tasks[ task ].progress or 0
	if amount then
		self.data.tasks[ task ].progress = math.Clamp(progress - amount, 0, self.data.tasks[ task ].progressneeded)
	else
		self.data.tasks[ task ].progress = math.Clamp(progress - 1, 0, self.data.tasks[ task ].progressneeded)
	end
	Mission:CheckStatus()
	Mission:UpdateClients()
end


util.AddNetworkString("openMissionMenu")
util.AddNetworkString("UpdateMissionTasks")

function PLUGIN:PlayerSpawn( client )
	Mission:UpdateClients()
end