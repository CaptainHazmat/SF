local PANEL = {}

local ScrW, ScrH = ScrW(), ScrH()

function PANEL:Init()
    if not LocalPlayer():IsAdmin() then return end

    nut.gui.MissionMenu = self


    self:SetSize(600, 436)
	if LocalPlayer().expandedMM then
		self:SetPos(ScrW/2 - 300, ScrH - 436)
	else
		self:SetPos(ScrW/2 - 300, ScrH - 36)
	end
	self:MakePopup()
	self:SetMouseInputEnabled(true)
	
	self.title = self:Add("DLabel")
	self.title:SetTall(36)
	self.title:Dock(TOP)
	self.title:SetFont("nutMediumFont")
	if Mission.data.name != "Нет Заданий" then
		self.title:SetText(Mission.data.name)
	else
		self.title:SetText("Меню Миссии ")
	end
	self.title:SetContentAlignment(5)
	self.title:SetTextInset(44, 0)
	self.title:SetTextColor(Color(250, 250, 250))
	self.title:SetExpensiveShadow(1, Color(0, 0, 0, 175))
	self.title.Paint = function(this, w, h)
		surface.SetDrawColor(nut.config.get("color"))
		surface.DrawRect(0, 0, w, h)
	end
	
	self.expand = self:Add("DButton")
	self.expand:SetContentAlignment(5)
	self.expand:SetText("О")
	self.expand:SetFont("nutIconsMedium")
	self.expand:SetDrawBackground(false)
	self.expand:SetTextColor(color_white)
	self.expand:SetExpensiveShadow(1, Color(0, 0, 0, 150))
	self.expand:SetSize(36, 36)
	self.expand.DoClick = function(this)
		if (LocalPlayer().expandedMM) then
			self:MoveTo(ScrW/2 - 300, ScrH - 36, 0.15)

			LocalPlayer().expandedMM = false
		else
			self:MoveTo(ScrW/2 - 300, ScrH - 436, 0.15, nil, nil, function()
				
			end)

			LocalPlayer().expandedMM = true
		end
	end
	
	self.scroll = self:Add("DScrollPanel")
	self.scroll:SetPos(0, 36)
	self.scroll:SetSize(600, 400)
	
	self.items = {}
	
	for k, v in pairs(Mission.data.tasks) do
		local panel = self.scroll:Add("DPanel")
		panel:SetTall(40)
		panel:Dock(TOP)
	
		panel.label = panel:Add("DLabel")
		panel.label:SetText(v.name .. " " .. v.progress .. "/" .. v.progressneeded)
		panel.label:SetTall(40)
		panel.label:Dock(TOP)
		panel.label:DockMargin(0, 1, 0, 0)
		panel.label:SetFont("nutMediumLightFont")
		panel.label:SetExpensiveShadow(1, Color(0, 0, 0, 150))
		panel.label:SetContentAlignment(9)
		panel.label:SetTextInset(8, 0)
		panel.label:SetTextColor(color_white)
		panel.label.Paint = function(s, w, h)
			nut.util.drawBlur(s)
			surface.SetDrawColor(nut.config.get("color"))
			surface.DrawRect(0, 0, w, 40)
		end
		
		panel.buttonplus = panel:Add("DButton")
		panel.buttonplus:SetText("+")
		panel.buttonplus:SetWide(40)
		panel.buttonplus:SetTall(40)
		panel.buttonplus:SetPos(0, 0)
		panel.buttonplus:SetFont("nutMediumLightFont")
		panel.buttonplus:SetExpensiveShadow(1, Color(0, 0, 0, 150))
		panel.buttonplus:SetContentAlignment(5)
		panel.buttonplus:SetTextInset(8, 0)
		panel.buttonplus:SetTextColor(color_white)
		panel.buttonplus.Paint = function(s, w, h)
			nut.util.drawBlur(s)
			surface.SetDrawColor(Color(65,65,65,200))
			surface.DrawRect(0, 0, w, 40)
		end
		panel.buttonplus.DoClick = function(s)
			nut.command.send("taskgive", k , 1)
		end
		
		panel.buttonminus = panel:Add("DButton")
		panel.buttonminus:SetText("-")
		panel.buttonminus:SetTall(40)
		panel.buttonminus:SetWide(40)
		panel.buttonminus:SetPos(41, 0)
		panel.buttonminus:SetFont("nutMediumLightFont")
		panel.buttonminus:SetExpensiveShadow(1, Color(0, 0, 0, 150))
		panel.buttonminus:SetContentAlignment(5)
		panel.buttonminus:SetTextInset(8, 0)
		panel.buttonminus:SetTextColor(color_white)
		panel.buttonminus.Paint = function(s, w, h)
			nut.util.drawBlur(s)
			surface.SetDrawColor(Color(65,65,65,200))
			surface.DrawRect(0, 0, w, 40)
		end
		panel.buttonminus.DoClick = function(s)
			nut.command.send("tasktake", k , 1)
		end
		
		panel.remove = panel:Add("DButton")
		panel.remove:SetText("X")
		panel.remove:SetTall(40)
		panel.remove:SetWide(40)
		panel.remove:SetPos(82, 0)
		panel.remove:SetFont("nutMediumLightFont")
		panel.remove:SetExpensiveShadow(1, Color(0, 0, 0, 150))
		panel.remove:SetContentAlignment(5)
		panel.remove:SetTextInset(8, 0)
		panel.remove:SetTextColor(color_white)
		panel.remove.Paint = function(s, w, h)
			nut.util.drawBlur(s)
			surface.SetDrawColor(Color(65,65,65,200))
			surface.DrawRect(0, 0, w, 40)
		end
		panel.remove.DoClick = function(s)
			nut.command.send("taskdel", k)
		end
		
		self.items[#self.items+1] = panel
	end
	if #Mission.data.tasks < 10 then
		self.scroll.buttonAdd = self.scroll:Add("DButton")
		self.scroll.buttonAdd:SetText("Добавить задачу")
		self.scroll.buttonAdd:SetTall(36)
		self.scroll.buttonAdd:Dock(TOP)
		self.scroll.buttonAdd:DockMargin(0, 1, 0, 0)
		self.scroll.buttonAdd:SetFont("nutMediumLightFont")
		self.scroll.buttonAdd:SetExpensiveShadow(1, Color(0, 0, 0, 150))
		self.scroll.buttonAdd:SetContentAlignment(5)
		self.scroll.buttonAdd:SetTextInset(8, 0)
		self.scroll.buttonAdd:SetTextColor(color_white)
		self.scroll.buttonAdd.Paint = function(s, w, h)
			nut.util.drawBlur(s)

			surface.SetDrawColor(Color(65,65,65,200))
			surface.DrawRect(0, 0, w, 40)
		end
		self.scroll.buttonAdd.DoClick = function(s)
			Derma_StringRequest( 
			"Название", 
			"Введите название задачи", 
			"", 
			function(text1) 
				Derma_StringRequest( 
				"Прогресс", 
				"Введите необходимый прогресс", 
				"", 
				function(text2) 
					nut.command.send("taskadd", text1, text2) 
				end,
				function(text2) 
				
				end,
				"OK",
				"Отмена")
			end,
			function(text1) 
			
			end,
			"OK",
			"Отмена")
		end
	end
	
	
end

function PANEL:Paint(w, h)
	nut.util.drawBlur(self)

	surface.SetDrawColor(nut.config.get("color"))
	surface.DrawRect(0, 0, w, 36)

	surface.SetDrawColor(255, 255, 255, 5)
	surface.DrawRect(0, 0, w, h)
end

vgui.Register("nutMissionMenu", PANEL, "EditablePanel")