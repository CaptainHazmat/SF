	local PANEL = {}
	local gradient = Material("vgui/gradient-d")
	local gradient2 = Material("vgui/gradient-u")

	local COLOR_SUCSESS = Color(0, 255, 0, 200)
	local COLOR_LOST = Color(255, 0, 0, 200)

	function PANEL:Init()
		local border = 16
		local scrW, scrH = ScrW(), ScrH()
		local w, h = scrW * 0.3, 32 + (#Mission.data.tasks * 28)
		nut.gui.tasks = self
		local function AddLabel(num, tbl)
			local label = self:Add("DLabel")
			label.taskNum = num
			label.tbl = tbl
			label:Dock(TOP)
			label:DockMargin(4, 4, 0, 4)
			label:SetFont("menu_22")
			local color = color_white
			if label.tbl.progress >= label.tbl.progressneeded then color = COLOR_SUCSESS end
			if Mission.data.failed == 2 then color = COLOR_LOST end
			label:SetTextColor(color)
			label:SetText(label.taskNum .. ") ".. label.tbl.name .. " " .. label.tbl.progress .. "/" .. label.tbl.progressneeded)
			label:SetExpensiveShadow(1, Color(0, 0, 0, 150))
			label.Think = function(this)
				if Mission.data.tasks[this.taskNum] then
					label.tbl = Mission.data.tasks[this.taskNum]
					this:SetText(label.taskNum .. ") ".. label.tbl.name .. " " .. label.tbl.progress .. "/" .. label.tbl.progressneeded)
					if label.tbl.progress >= label.tbl.progressneeded then color = COLOR_SUCSESS elseif label.tbl.progress < label.tbl.progressneeded then color = color_white end
					if Mission.data.failed == 2 then color = COLOR_LOST end
					this:SetTextColor(color)
				else
					this:Remove()
				end
			end
			self.tasks[#self.tasks + 1] = label
			return label
		end

		nut.gui.missiontasks = self

		self:SetSize(w, h)
		self:SetPos(ScrW() - w - border, 0)
		
		self.missionName = self:Add("DPanel")
		self.missionName:Dock(TOP)
		self.missionName:SetTall(32)
		local color2 = color_white
		self.missionName.label = self.missionName:Add("DLabel")
		self.missionName.label:SetFont("menu_22")
		self.missionName.label:Dock(FILL)
		self.missionName.label:DockMargin(8, 0, 0, 0)
		self.missionName.label:SetTextColor(color_white)
		self.missionName.label:SetExpensiveShadow(1, Color(0, 0, 0, 150))
		self.missionName.label.Think = function(this)
				local text = 'Операция: ' .. Mission.data.name
				if Mission.data.failed == 2 then
					text = text .. " | Статус : ПРОВАЛЕНА"
				elseif Mission.data.failed == 0 then
					text = text .. " | Статус : Выполняется"
				elseif Mission.data.failed == 1 then
					text = text .. " | Статус : Выполнено!"
				end
				this:SetText(text)
				if Mission.data.failed == 2 then color2 = COLOR_LOST elseif Mission.data.failed == 0 then color2 = color_white elseif Mission.data.failed == 1 then color2 = color_green end
				this:SetTextColor(color2)
			end
		
		self.tasks = {}
		if Mission.data.tasks and Mission.data.tasks[1] then
			for k,v in pairs(Mission.data.tasks) do
				AddLabel(k,v)
				
			end
		end
	end

	function PANEL:Paint(w, h)
		nut.util.drawBlur(self, 2)

		surface.SetDrawColor(250, 250, 250, 2)
		surface.DrawRect(0, 0, w, h)
	end
	
	function PANEL:Think()
		if (gui.IsGameUIVisible() and self.active) then
			self:Remove()
		end
		
		if #self.tasks != #Mission.data.tasks then
			self:Remove()
			vgui.Create("nutTasksBox")
		end
	end
	
vgui.Register("nutTasksBox", PANEL, "DPanel")