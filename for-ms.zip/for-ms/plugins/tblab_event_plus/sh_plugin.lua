/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

PLUGIN.name = "Event payment and money giver"
PLUGIN.desc = "Система выдачи зарплат на ивенте. Переделка зарплат по часам и денег за ивенты"
PLUGIN.author = "Tium#2016 (_tium_)"
local PLUGIN = PLUGIN
--------------Включения-------------------
nut.util.include("sv_plugin.lua")
------------------------------------------
 
if CLIENT then
	netstream.Hook("introtext", function(name)
		local event_name = "Операция - " .. "\""..name.. "\""
		write_map2(event_name)
	end)
end

nut.command.add("startevent", {
	adminOnly = true,
	syntax = "<string name>",
	onRun = function(client, arguments)
		if (arguments[1] == nil) or (arguments[1] == "") then return end
		for k,v in pairs(player.GetAll()) do
			netstream.Start(v, "introtext", tostring(arguments[1]))
		end
		PLUGIN:StartEvent(client,tostring(arguments[1]))
		if Mission.data.name != "Нет Заданий" then Mission.data.name = tostring(arguments[1]) end
		Mission:UpdateClients()
	end
})

local client, sx, sy, scrPos, marginx, marginy, x, y, teamColor, distance, factor, size, alpha
local dimDistance = 1024
function PLUGIN:HUDPaint()
	if LocalPlayer():getChar() != nil then
		sx, sy = surface.ScreenWidth(), surface.ScreenHeight()
		for k,v in pairs(ents.FindByClass( "nut_point" )) do
			scrPos = v:GetPos():ToScreen()
			marginx, marginy = sy*.1, sy*.1
			x, y = math.Clamp(scrPos.x, marginx, sx - marginx), math.Clamp(scrPos.y, marginy, sy - marginy)
			distance = LocalPlayer():GetPos():Distance(v:GetPos())
			factor = 1 - math.Clamp(distance/dimDistance, 0, 1)
			size = math.max(64, 128*factor)
			alpha = math.Clamp(255*factor, 80, 255)
			surface.SetDrawColor(Color(0,255,0))
			surface.SetMaterial(Material("hud/point.png")) 
			surface.DrawTexturedRect(x - size/2, y - size/2, size, size)
		end
	end
end