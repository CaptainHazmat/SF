local PANEL = {}
	local gradient = nut.util.getMaterial("daui/menubutton.png")
	local gradient2 = nut.util.getMaterial("vgui/gradient-d")
	local alpha = 80
	local font = "menu_40"
	function PANEL:Init()
		if (IsValid(nut.gui.menu)) then
			nut.gui.menu:Remove()
		end

		nut.gui.menu = self

		self:SetSize(ScrW(), ScrH())
		self:SetAlpha(0)
		self:AlphaTo(255, 0.25, 0)
		self:SetPopupStayAtBack(true)
		
		self.panel = self:Add("EditablePanel")
		self.panel:SetSize(ScrW(), ScrH()*14/16)
		self.panel:SetPos(0, ScrH()/16)
		self.panel:SetAlpha(0)
		
		self.panelup = self:Add("DPanel") -- панель для верха
		self.panelup:Dock(TOP)
		self.panelup:DockMargin(0,0,0,0)
		self.panelup:SetTall(ScrH()/16)
		self.panelup.Paint = function( self, w, h )

			surface.SetDrawColor(Color(75, 75, 75, 255))
			surface.DrawRect(20, ScrH()/16-6, w-40, 3)
			
		end
		
		self.panelup.text = self.panelup:Add("DLabel")
		self.panelup.text:SetColor(color_white)
		self.panelup.text:SetFont(font)
		self.panelup.text:SetText("ТЕСТ_ТЕСТ_ТЕСТ_")
		self.panelup.text:SizeToContents()
		self.panelup.text:Dock(LEFT)
		self.panelup.text:DockMargin( 100,10,0,0)
		
		
		self.panelleft = self:Add("DPanel") -- панель для кнопок
		self.panelleft:Dock(BOTTOM)
		self.panelleft:DockMargin(0,0,0,0)
		self.panelleft:SetTall(ScrH()/16)
		
		self.panelleft.tabs = self.panelleft:Add("DScrollPanel") -- кнопки
		self.panelleft.tabs:SetPos(0, 0)
		self.panelleft.tabs:SetWide(ScrW())
		self.panelleft.tabs:SetTall(ScrH()/16)

		local tabs = {}

		hook.Run("CreateMenuButtons", tabs)

		self.tabList = {}
		
		for name, callback in SortedPairs(tabs) do
			if (type(callback) == "string") then
				local body = callback

				if (body:sub(1, 4) == "http") then
					callback = function(panel)
						local html = panel:Add("DHTML")
						html:Dock(FILL)
						html:OpenURL(body)
					end
				else
					callback = function(panel)
						local html = panel:Add("DHTML")
						html:Dock(FILL)
						html:SetHTML(body)
					end
				end
			end

			local tab = self:addTab(L(name), callback, name)
			self.tabList[name] = tab
		end
		
		self.noAnchor = CurTime() + .4
		self.anchorMode = true
		self:MakePopup()

		self.info = vgui.Create("nutCharInfo", self)
		self.info:setup()
		self.info:SetAlpha(0)
		self.info:AlphaTo(255, 0.5)
		self.info:SetSize(ScrW(), ScrH()*14/16)
		self.info:SetPos(0, ScrH()/16)
		self.panelup.text:SetText("Персонаж")
	end

	function PANEL:OnKeyCodePressed(key)
		self.noAnchor = CurTime() + .5

		if (key == KEY_F1) then
			self:remove()
		end
	end

	function PANEL:Think()
		local key = input.IsKeyDown(KEY_F1)
		if (key and (self.noAnchor or CurTime()+.4) < CurTime() and self.anchorMode == true) then
			self.anchorMode = false
			surface.PlaySound("buttons/lightswitch2.wav")
		end

		if (!self.anchorMode) then
			if (IsValid(self.info)) then
				return
			end

			if (!key) then
				self:remove()
			end
		end
	end

	local color_bright = Color(255, 255, 255, 255)

	function PANEL:Paint(w, h)
		nut.util.drawBlur(self, 12)
		local x, y = gui.MousePos()
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/main.png"))
		surface.DrawTexturedRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/sflogo.png"))
		surface.DrawTexturedRect(10, 10, 54, 41)

	end

	function PANEL:addTab(name, callback, uniqueID)
		name = L(name)

		local function paintTab(tab, w, h)
			-- surface.SetDrawColor(Color(255, 255, 255, 255))
			-- surface.SetMaterial(Material("hud/main.png"))
			-- surface.DrawTexturedRect(0, 0, w, h)
			
			if (self.activeTab == tab) then
				surface.SetDrawColor(Color(255,0,0))  -- когда выбрана
				surface.DrawRect(0, h - 8, w, 8)
			elseif (tab.Hovered) then
				surface.SetDrawColor(255, 0, 0, 100) -- когда накрыта
				surface.DrawRect(0, h - 8, w, 8)
			end
		end

		surface.SetFont("menu_30") -- 30
		local w = surface.GetTextSize(name)

		local tab = self.panelleft.tabs:Add("DButton")
			tab:SetText(name)
			tab:SetTextColor(Color(255, 255, 255))
			tab:SetFont("menu_30") --30
			tab:SizeToContentsX()
			tab:SizeToContents(Y)
			tab:SetTall((ScrH()/16)-20)
			tab:SetWide(w)
			tab:Dock(LEFT)
			tab:DockMargin(40,10,0,0)
			tab.Paint = paintTab
			tab.DoClick = function(this)
				self.panel:Clear()
				self.info:Remove()
				self.panel:AlphaTo(255, 0.5, 0.1)
				self.activeTab = this
				lastMenuTab = uniqueID
				if (callback) then
				self.panelup.text:SetText(name)
					callback(self.panel, this)
				end
			end
		self.panelleft.tabs:AddItem(tab)

		return tab
	end



	function PANEL:setActiveTab(key)
		if (IsValid(self.tabList[key])) then
			self.tabList[key]:DoClick()
		end
	end

	function PANEL:OnRemove()
	end

	function PANEL:remove()
		CloseDermaMenus()
		
		if (!self.closing) then
			self:AlphaTo(0, 0.25, 0, function()
				self:Remove()
			end)
			self.closing = true
		end
	end
vgui.Register("nutMenu", PANEL, "EditablePanel")

if (IsValid(nut.gui.menu)) then
	vgui.Create("nutMenu")
end	