--[[
Server Name: [НОВАЯ ИГРА] WarfareRP#1 Затон
Server IP:   45.136.204.155:27025
File Path:   addons/script_pizza_binds/lua/autorun/cl_radialmenu.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

if SERVER then return end

local function Circle( x, y, radius, seg )
	local cir = {}

	table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
	for i = 0, seg do
		local a = math.rad( ( i / seg ) * -360 )
		table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
	end

	local a = math.rad( 0 )
	table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

	surface.DrawPoly( cir )
end

local Initialize = nil
local path = "nutscript/"..SCHEMA.folder.."/"
local file_name = "tblab_radial"
local resolution = ".txt"

if !file.Exists(path .. file_name .. resolution, "DATA") then
    file.CreateDir(path)
    file.Append(path  .. file_name .. resolution)
end

local function update_file(content)
    file.Write(path .. file_name .. resolution, util.TableToJSON(content))
end

local FILE_DATA = util.JSONToTable(file.Read(path  .. file_name .. resolution, "DATA")) or {}

if !util.JSONToTable(file.Read(path  .. file_name .. resolution, "DATA")) then
    FILE_DATA.Recognize = {}
    FILE_DATA.FakeRecognize = {}
else
    FILE_DATA.Recognize = util.JSONToTable(file.Read(path  .. file_name .. resolution, "DATA")).Recognize or {}
    FILE_DATA.FakeRecognize = util.JSONToTable(file.Read(path  .. file_name .. resolution, "DATA")).FakeRecognize or {}
end

local pmeta = FindMetaTable("Player")

function pmeta:GetSelfRecognize(bFake,client)
    if bFake == true then
        if FILE_DATA.FakeRecognize[client:getChar():getID()] == true then
            return false
        else
            return true
        end
    else
        if FILE_DATA.Recognize[client:getChar():getID()] == true then
            return false
        else
            return true
        end
    end
end

WasOpenMenu = false
LoadTable = nil
fade = 0

mouseang = 0
mouserad = 0

local function RadiusSpoke(x, y, angle, rad)
    x = x + (math.cos(angle) * rad)
    y = y + (math.sin(angle) * rad)

    return x, y
end

local segmentfadetime = 0.25
local fadetime = 0.1
active_text = ""

hook.Remove("HUDPaint", "btnlist_HUD")
hook.Add("HUDPaint", "btnlist_HUD", function()
    if WasOpenMenu then 
        if !LoadTable then
            btnlist = {
                {
                    name = "Представиться",
                    callback = function(int_char)
                        netstream.Start("rgn")
                        --FILE_DATA.Recognize[int_char:getChar():getID()] = true
                        --update_file(FILE_DATA)
                    end,
                    condition = function(int_char)
                        return true--!LocalPlayer():GetSelfRecognize(false,int_char)
                    end,
                    sfade = 0,
                    icon = "recognise"
                },
				
                {
                    name = "Документы",
                    callback = function(int_char)
						local item = LocalPlayer():getChar():getInv():hasItem('documentid')
						netstream.Start("invAct", "use", item.id, LocalPlayer():getChar():getInv():getID())
                    end,
                    condition = function(int_char)
							if LocalPlayer():getChar():getInv():hasItem('documentid') then return true else return false end
						end,
                    sfade = 0,
                    icon = "docs"
                },
                {
                    name = "Заковать",
                    callback = function(int_char)
                        local item = LocalPlayer():getChar():getInv():hasItem('tie')
						netstream.Start("invAct", "Use", item.id, LocalPlayer():getChar():getInv():getID())
                    end,
                    condition = function(int_char) return !int_char:getNetVar("restricted", false) and LocalPlayer():getChar():getInv():hasItem("tie") and !LocalPlayer():getNetVar("restricted", false) end,
                    sfade = 0,
                    icon = "cuff"
                },
                {
                    name = "Обыскать",
                    callback = function(int_char)
                        nut.command.send("charsearch")
                    end,
                    condition = function(int_char) return int_char:getNetVar("restricted", false) end,
                    sfade = 0,
                    icon = "search"
                },
				{
                    name = "Расковать",
                    callback = function(int_char)
                        nut.command.send("uncuff")
                    end,
                    condition = function(int_char) return int_char:getNetVar("restricted", false) and LocalPlayer():getChar():getInv():hasItem("tie") and !LocalPlayer():getNetVar("restricted", false) end,
                    sfade = 0,
                    icon = "cuff"
                },
				{
                    name = "Повысить",
                    callback = function(int_char)
                        nut.command.send("ranksup",int_char:Name())
                    end,
                    condition = function(int_char)
							if (nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain") == (nut.faction.indices[int_char:Team()].ranktable or "Ranksmain") then 
								local RTABLE = SCHEMA.RanksData[nut.faction.indices[LocalPlayer():Team()].ranktable]
								if int_char:getNetVar("rank", 1) >= LocalPlayer():getNetVar("rank", 1) then return false end
								if RTABLE.canup[LocalPlayer():getNetVar("rank", 1)] > int_char:getNetVar("rank", 1) then return true else return false end
							else
								return false
							end
						end,
                    sfade = 0,
                    icon = "rup"
                },
				{
                    name = "Понизить",
                    callback = function(int_char)
                        nut.command.send("ranksdown",int_char:Name())
                    end,
                    condition = function(int_char)
							if (nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain") == (nut.faction.indices[int_char:Team()].ranktable or "Ranksmain") then 
								local RTABLE = SCHEMA.RanksData[nut.faction.indices[LocalPlayer():Team()].ranktable]
								if int_char:getNetVar("rank", 1) >= LocalPlayer():getNetVar("rank", 1) then return false end
								if RTABLE.canup[LocalPlayer():getNetVar("rank", 1)] >= int_char:getNetVar("rank", 1) then return true else return false end
							else
								return false
							end 
						end,
                    sfade = 0,
                    icon = "rdown"
                },
				{
                    name = "Водительские права",
                    callback = function(int_char)
                        nut.command.send("givepravacar",int_char:Name())
                    end,
                    condition = function(int_char)
							if (nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain") == (nut.faction.indices[int_char:Team()].ranktable or "Ranksmain") then 
								if LocalPlayer():getChar():hasFlags("F") then return true end
							else
								return false
							end
						end,
                    sfade = 0,
                    icon = "gpc"
                },
				{
                    name = "Забрать права",
                    callback = function(int_char)
                        nut.command.send("removepravacar",int_char:Name())
                    end,
                    condition = function(int_char)
							if (nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain") == (nut.faction.indices[int_char:Team()].ranktable or "Ranksmain") then 
								if LocalPlayer():getChar():hasFlags("F") then return true end
							else
								return false
							end
						end,
                    sfade = 0,
                    icon = "rpc"
                },
				{
                    name = "Лицензия пилота",
                    callback = function(int_char)
                        nut.command.send("givepravaup",int_char:Name())
                    end,
                    condition = function(int_char)
							if (nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain") == (nut.faction.indices[int_char:Team()].ranktable or "Ranksmain") then 
								if LocalPlayer():getChar():hasFlags("F") then return true end
							else
								return false
							end
						end,
                    sfade = 0,
                    icon = "gpu"
                },
				{
                    name = "Забрать лицензию",
                    callback = function(int_char)
                        nut.command.send("removepravaup",int_char:Name())
                    end,
                    condition = function(int_char)
							if (nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain") == (nut.faction.indices[int_char:Team()].ranktable or "Ranksmain") then 
								if LocalPlayer():getChar():hasFlags("F") then return true end
							else
								return false
							end
						end,
                    sfade = 0,
                    icon = "rpu"
                },
                {
                    name = "Передать деньги",
                    callback = function()
                        local FR_FRAME = vgui.Create("DFrame")
                        FR_FRAME:SetSize(ScrW() * 0.4, ScrH() * 0.2)
                        FR_FRAME:Center()
                        FR_FRAME:SetTitle("Передача денег")
                        FR_FRAME:SetAlpha(0)
                        FR_FRAME:SetDraggable(false)
                        FR_FRAME:ShowCloseButton(false)
                        FR_FRAME:MakePopup()
                        FR_FRAME:AlphaTo(255, 0.5, 0)

                        function FR_FRAME:Paint( w, h )
                            nut.util.drawBlur(self, 10)
                            surface.SetDrawColor(Color( 30, 30, 30, 190))
                            surface.DrawRect( 0, 0, w, h )
                            surface.DrawOutlinedRect(0, 0, w, h)

                            surface.SetDrawColor(0, 0, 14, 150)
                            surface.DrawRect(ScrW() * 0, ScrH() * 0, ScrW() * 0.41, ScrH() * 0.033)

                            surface.SetDrawColor(Color( 30, 30, 30, 50))
                            surface.DrawOutlinedRect(ScrW() * 0, ScrH() * 0, ScrW() * 0.41, ScrH() * 0.033)
                        end

                        local FR_LABEL = FR_FRAME:Add("DLabel")
                        FR_LABEL:SetText("Введите сумму для передачи денег:")
                        FR_LABEL:SetFont("nutMediumFont")
                        FR_LABEL:Dock(TOP)
                        FR_LABEL:DockMargin(0, 40, 0, 0)
                        FR_LABEL:SetTextColor(color_white)
                        FR_LABEL:SizeToContents()
                        FR_LABEL:SetTextInset(select(1,FR_FRAME:GetSize()) * 0.03, 0)

                        local FR_ENTRY = FR_FRAME:Add("DTextEntry")
                        FR_ENTRY:SetText("")
                        FR_ENTRY:SetFont("nutMediumFont")
                        FR_ENTRY:Dock(TOP)
                        FR_ENTRY:DockMargin(select(1,FR_FRAME:GetSize()) * 0.03, 10, 0, 0)
                        FR_ENTRY:SetTall(select(2,FR_FRAME:GetSize()) * 0.15)
                        FR_ENTRY:SetTextColor(color_white)
                        FR_ENTRY:SetZPos(999)
                        FR_ENTRY:SizeToContents()
                        FR_ENTRY.Paint = function(s,w,h)
                            surface.SetDrawColor(Color(255, 0, 0, 100))
                            surface.SetMaterial(nut.util.getMaterial("vgui/gradient-l.vtf"))
                            surface.DrawTexturedRect(0, 0, w, h)

                            s:DrawTextEntryText(color_white, color_white, color_white)
                        end

                        FR_ENTRY.OnEnter = function(pnl)
                            if isnumber(tonumber(pnl:GetText())) then
                                if LocalPlayer():getChar():getMoney() >= tonumber(pnl:GetText()) then
									nut.command.send("givemoney",tonumber(pnl:GetText()))
                                else
                                    nut.util.notify("Не хватает денег.")
                                end
                            end
                            FR_EXIT:Remove()
                            FR_FRAME:Remove()
                        end

                        local FR_HELP = FR_FRAME:Add("DLabel")
                        FR_HELP:SetText("чтобы задать количество денег нажмите <ENTER> после ввода текста!")
                        FR_HELP:SetFont("nutSmallFont")
                        FR_HELP:Dock(TOP)
                        FR_HELP:DockMargin(0, 3, 0, 0)
                        FR_HELP:SetTextColor(Color(255, 0, 0, 100))
                        FR_HELP:SizeToContents()
                        FR_HELP:SetTextInset(select(1,FR_FRAME:GetSize()) * 0.03, 0)

                        local function buttonPaint(s, w, h)
                            if s:IsDown() then 
                                surface.SetDrawColor(Color( 255, 0, 0, 40))
                                surface.DrawRect(0, 0, w, h)

                                surface.SetDrawColor(Color( 255, 0, 0, 45))
                                surface.DrawOutlinedRect(0, 0, w, h)
                            elseif s:IsHovered() then 
                                surface.SetDrawColor(Color( 255, 0, 0, 20))
                                surface.DrawRect(0, 0, w, h)

                                surface.SetDrawColor(Color( 255, 0, 0, 25))
                                surface.DrawOutlinedRect(0, 0, w, h)
                            else
                                surface.SetDrawColor(Color( 30, 30, 30, 245))
                                surface.DrawRect(0, 0, w, h)

                                surface.SetDrawColor(Color( 0, 0, 0, 245))
                                surface.DrawOutlinedRect(0, 0, w, h)
                            end
                        end

                        FR_EXIT = vgui.Create("DButton")
                        FR_EXIT:SetText("ОТМЕНИТЬ")
                        FR_EXIT:SetFont("nutSmallFont")
                        FR_EXIT:MakePopup()
                        FR_EXIT:SetSize(FR_FRAME:GetWide(), select(2,FR_FRAME:GetSize()) * 0.2)
                        FR_EXIT:SetPos(select(1, FR_FRAME:GetPos()), select(2, FR_FRAME:GetPos()) * 1.53)
                        FR_EXIT:SetTextColor(color_white)
                        FR_EXIT.Paint = buttonPaint
                        FR_EXIT.DoClick = function(s)
                            s:Remove()
                            FR_FRAME:Remove()
                        end
                    end,
                    condition = function() return true end,
                    sfade = 0,
                    icon = "money"
                },
            }
            LoadTable = true
        end

        activemenu = btnlist

        if !activemenu then return end

        segments = #activemenu

        for i=1,segments do
            if activemenu[i] and activemenu[i].condition then
                if activemenu[i].condition(int_char) == false then
                    table.remove(activemenu, i)
                end
            end
        end

        segments = #activemenu

        if !activemenu then return end

        if WasOpenMenu then
            fade = math.Approach(fade, 1, FrameTime() / fadetime)
        else
            fade = math.Approach(fade, 0, FrameTime() / fadetime)
        end

        if IsValid(int_char) then
            if LocalPlayer():GetPos():Distance(int_char:GetPos()) >= 100 then
                WasOpenMenu = false
                LoadTable = nil
                int_char,active_func,condition = nil
            end
        end
        
        local a = fade * 255

        if a <= 0 then return end

        local ss = ScreenScale(1)

        local col_fg = Color(255, 255, 255, a)
        local col_fg_h = Color(25, 25, 25, a)
        if !int_char then return false end
		
        surface.SetDrawColor(0, 0, 0, 100)
        surface.DrawRect(0, 0, ScrW(), ScrH())
        
        local x = ScrW() / 2
        local y = ScrH() * 0.47

        local rad = ss * 50

        if segments > 0 then

            local arc = 360 / segments

            for i = 1, segments do
                local angle = (i * arc) - 90

                local d = (mouseang - angle + 180 + 360) % 360 - 180
                d = math.abs(d)

                local selected = d <= arc / 2

                if mouserad == 0 then
                    selected = false
                end

                if !activemenu[i] then continue end
                activemenu[i].sfade = activemenu[i].sfade or 0

                local size = rad * (1 + (activemenu[i].sfade * 0.1))

                local inf_x, inf_y = RadiusSpoke(x, y, math.rad(angle), size)

                if selected then
                    btnlist_Selection = i
                    activemenu[i].sfade = math.Approach(activemenu[i].sfade, 0.5, FrameTime() / segmentfadetime)
                    active_text = activemenu[i].name
                    active_func = activemenu[i].callback
                else
                    activemenu[i].sfade = math.Approach(activemenu[i].sfade, 0, FrameTime() / segmentfadetime)
                end

                local inf_w, inf_h = ScrW() * 0.0335, ScrH() * 0.0593

                local tb_w = inf_w

                --print(inf_w,inf_h)
                local inf_w, inf_h = ScrW() * 0.0335, ScrH() * 0.0593
                local tb_w = inf_w

                if selected then
                    surface.SetDrawColor(250, 225, 172, a * 1)
                else
                    surface.SetDrawColor(255, 255, 255, a * 0.4)
                end
                surface.SetMaterial(Material("hud/" .. activemenu[i].icon .. ".png"))
                surface.DrawTexturedRect(inf_x - (tb_w * 0.5), inf_y - (ss * 5), tb_w, inf_h)

                if selected then
                    surface.SetTextColor(col_fg_h)
                else
                    surface.SetTextColor(col_fg)
                end
            end

            draw.DrawText(active_text or "", "nutMediumFont", x, y, Color(255, 255, 255,255), TEXT_ALIGN_CENTER)
            if (!int_char) then return false end
            draw.DrawText([[Чтобы закрыть меню нажмите повторно ]] .. input.LookupBinding("+use"), "nutMediumFont", x, ScrH() -64, Color(255,255,255,200), TEXT_ALIGN_CENTER)
        end

        local pick_x, pick_y = RadiusSpoke(x, y, math.rad(mouseang), mouserad)
        local pick_s = ss * 5

        surface.SetDrawColor(255, 255, 255, a)
        draw.NoTexture()
        Circle(pick_x - (pick_s / 2), pick_y - (pick_s / 2), 6.5, 50)
        surface.DrawCircle(pick_x - (pick_s / 2), pick_y - (pick_s / 2), 7, Color(0,0,0))

		LocalPlayer().lastWeap = LocalPlayer():GetActiveWeapon()
        input.SelectWeapon(LocalPlayer():GetWeapon("nut_hands"))
        
        if input.IsMouseDown(MOUSE_LEFT) then
            if active_func and isfunction(active_func) then
                if condition then
                    if isfunction(condition) and condition(int_char) == true then
                        active_func(int_char)
						input.SelectWeapon(LocalPlayer().lastWeap)
						LocalPlayer().lastWeap = nil
                    end
                else
                    active_func(int_char)
					input.SelectWeapon(LocalPlayer().lastWeap)
					LocalPlayer().lastWeap = nil
                    LoadTable = nil
                    WasOpenMenu = false
                    alpha = 0
                    int_char,active_func,condition = nil
                end
            end
        end
    end
end)

hook.Add("KeyPress", "tblab.ent.int", function(ply,key)
    if key == IN_USE then
        if !ply:getNetVar("restricted") then
            if (pizza_cd or 0) <= CurTime() then
                if !WasOpenMenu then
                    local target = ply:GetEyeTrace().Entity
                    if IsValid(target) and target:IsPlayer() and target:GetPos():Distance(ply:GetPos()) <= 100 and !target:GetNoDraw() then
                        WasOpenMenu = true
                        int_char = target
                    end
                else
					input.SelectWeapon(LocalPlayer().lastWeap)
					LocalPlayer().lastWeap = nil
                    LoadTable = nil
                    alpha = 0
                    WasOpenMenu = false
                    int_char,active_func,condition = nil
                end
                pizza_cd = CurTime() + 0.5
            end
        end
    end
end)


hook.Add("InputMouseApply", "btnlist_Mouse", function(cmd, x, y, ang)
    if !WasOpenMenu then return end

    if math.abs(x) + math.abs(y) <= 0 then return end

    cmd:SetMouseX( 0 )
    cmd:SetMouseY( 0 )

    local mousex = math.cos(math.rad(mouseang)) * mouserad
    local mousey = math.sin(math.rad(mouseang)) * mouserad

    mousex = mousex + x
    mousey = mousey + y

    local newang = math.deg(math.atan2(mousey, mousex))
    local newrad = math.sqrt(math.pow(mousex, 2) + math.pow(mousey, 2))
    -- local newrad = Vector(mousex, mousey):Length()

    newrad = math.min(newrad, ScreenScale(25))

    mouserad = newrad
    mouseang = newang

    return true
end)