local PLUGIN = PLUGIN

PLUGIN.name = "TimeBreaker User Interface"
PLUGIN.author = "Корби#9995 & Tium#2016"
PLUGIN.desc = ""
PLUGIN.version = 1

local IncludeFiles = {"sh_config.lua"}
for k, v in ipairs(IncludeFiles) do nut.util.include(v) end