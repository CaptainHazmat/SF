FACTION.name = "[ШТАБ]" -- название
FACTION.desc = "[    ]" -- 
FACTION.health = 100 -- хп
FACTION.armor = 0	-- броня
FACTION.color = Color(255, 0, 0) -- цвет в табе
FACTION.isDefault = false -- важно! не менять!
FACTION.isGloballyRecognized = false	-- важно не менят!
FACTION.ranktable = "Ranksevent"
FACTION.models = {

}
FACTION.weapons = {"weapon_rdo_radio",}

function FACTION:onSpawn(client)
	for k,v in pairs(self.weapons) do
		client:Give(v)
	end
    --client:SetKeycardLevel(2)
    --client:SetArmor(self.armor)
end
function FACTION:onTransfered(client, oldFaction)
	client:getChar():setData("lastClass", nil)
end
FACTION_ADMIN = FACTION.index -- индекс