PLUGIN.name = "Scoreboard"
PLUGIN.author = "Cheesenut"
PLUGIN.desc = "A simple scoreboard that supports recognition."

if (CLIENT) then
	function PLUGIN:ScoreboardHide()
		if (IsValid(nut.gui.score)) then
			nut.gui.score:SetVisible(false)
			CloseDermaMenus()
		end

		gui.EnableScreenClicker(false)
		return true
	end

	function PLUGIN:ScoreboardShow()
		if (IsValid(nut.gui.score)) then
			nut.gui.score:SetVisible(true)
		else
			vgui.Create("nutScoreboard")
		end

		gui.EnableScreenClicker(true)
		return true
	end

	function PLUGIN:OnReloaded()
		-- Reload the scoreboard.
		if (IsValid(nut.gui.score)) then
			nut.gui.score:Remove()
		end
	end

	function PLUGIN:ShowPlayerOptions(client, options)
	
		options["Профиль"] = {"icon16/user.png", function()
			if (IsValid(client)) then
				client:ShowProfile()
			end
		end}
		
		-- options["Повысить"] = {"icon16/user.png", function()
			-- if (IsValid(client)) then
				-- nut.command.send("ranksup", client:Name())
			-- end
		-- end}
		
		-- options["Понизить"] = {"icon16/user.png", function()
			-- if (IsValid(client)) then
				-- nut.command.send("ranksdown", client:Name())
			-- end
		-- end}
		
		if LocalPlayer():IsAdmin() then
		
			options["Смена имени"] = {"icon16/user.png", function()
				Derma_StringRequest("Изменить имя персонажа", "Какое имя ты хочешь установить?", client:Name(), function(text)
					nut.command.send("charsetname", client:Name(), text)
				end, nil, "Изменить", "Отмена")
			end}
			
			options["Copy Steam ID"] = {"icon16/user.png", function()
				if (IsValid(client)) then
					SetClipboardText(client:SteamID())
				end
			end}
			
			options["Смена фракции"] = {"icon16/user.png", function()
				local menu = vgui.Create("DFrame")
				menu:SetSize(ScrW() / 4.5, ScrH() / 4)
				menu:MakePopup()
				menu:Center()
				menu:SetTitle("Изменить фракцию игрока")
				local listfact = menu:Add("DScrollPanel")
				listfact:SetSize(ScrW() / 5, ScrH() / 5)
				listfact:Center()
				

				for k, v in pairs(nut.faction.indices) do
					local button = vgui.Create("DButton", listfact)
					button:Dock(TOP)
					button:SetText(L(v.name))
					button:SetTall(30)
					button.DoClick = function()
						nut.command.send("plytransfer", client:Name(), v.uniqueID)
						menu:Remove()
					end
				end
			end}
			
			options["Смена модели"] = {"icon16/user.png", function()
				Derma_StringRequest("Изменить модель персонажа", "Какую модель ты хочешь установить?", client:GetModel(), function(text)
					nut.command.send("charsetmodel", client:Name(), text)
				end, nil, "Изменить", "Отмена")
			end}
			
			options["Смена ранга"] = {"icon16/user.png", function()
				local menu = vgui.Create("DFrame")
				menu:SetSize(ScrW() / 6, ScrH() / 4)
				menu:SetBackgroundBlur(false)
				menu:MakePopup()
				menu:Center()
				menu:SetTitle("Изменить ранг игрока")
				local listranks = menu:Add("DScrollPanel")
				listranks:SetSize(ScrW() / 7, ScrH() / 5)
				listranks:Center()
				local fact = nut.faction.indices[client:Team()]
				local Rtable = fact.ranktable or "Ranksmain"
				--PrintTable() 
				local RD = SCHEMA.RanksData[Rtable]
				for k, v in pairs(RD.ranks) do
					local button = vgui.Create("DButton", listranks)
					button:Dock(TOP)
					button:SetText(k.. ". " .. v .. " - " .. SCHEMA.RanksData[Rtable].translate[k])
					button:SetTall(30)
					button.Paint = function(w, h)
						surface.SetDrawColor(0, 0, 0, 255)
						surface.DrawRect(0, 0, button:GetWide(), button:GetTall())  
						surface.DrawOutlinedRect( 0, 0, button:GetWide(), button:GetTall(), 0, 0 )
					end
					button.DoClick = function()
						nut.command.send("arank", client:Name(), k)
						menu:Remove()
					end
				end
			end}
		end
		
		if LocalPlayer():IsSuperAdmin() then
			options["Выдать предмет"] = {"icon16/user.png", function()
				local menu = vgui.Create("DFrame")
				menu:SetSize(ScrW() / 4.5, ScrH() / 4)
				menu:MakePopup()
				menu:Center()
				menu:SetTitle("Лист предметов")
				local menu2	
				menu.items = menu:Add("DListView")
				menu.items:Dock(FILL)
				menu.items:DockMargin(0, 4, 0, 0)
				menu.items:AddColumn(L"name").Header:SetTextColor(color_black)
				menu.items:SetMultiSelect(false)
				menu.items.OnRowRightClick = function(this, index, line)
					if (IsValid(menu2)) then
						menu2:Remove()
					end

					local uniqueID = line.item

					menu2 = DermaMenu()
					local mode, panel = menu2:AddSubMenu("Выдать")
					panel:SetImage("icon16/key.png")

					mode:AddOption("1 вещь", function()
						nut.command.send("chargiveitem", client:Name(), uniqueID)
						--client:getChar():getInv():add(uniqueID)
						--print(uniqueID)
					end):SetImage("icon16/key.png")
					mode:AddOption("Несколько", function()
						Derma_StringRequest( "Выдача предметов", "Введите количество", "1",
						function(text) 	
							local count = tonumber(text)
							local t = 0
							for i = 1, count do
								timer.Simple( t, function() nut.command.send("chargiveitem", client:Name(), uniqueID) end )
								t = t + 1
							end
						end,
						function(text)  end)
					end):SetImage("icon16/key.png")
					menu2:Open()
				end
				
				menu.lines = {}

				for k, v in SortedPairs(nut.item.list) do
					local panel = menu.items:AddLine((L(v.name)) or L"none")

					panel.item = k
					menu.lines[k] = panel
				end
			end}
		end
	end
end

nut.config.add(
	"sbWidth",
	0.325,
	"Scoreboard's width within percent of screen width.",
	function(oldValue, newValue)
		if (CLIENT and IsValid(nut.gui.score)) then
			nut.gui.score:Remove()
		end
	end,
	{
		form = "Float",
		category = "visual",
		data = {min = 0.2, max = 1}
	}
)

nut.config.add(
	"sbHeight",
	0.825,
	"Scoreboard's height within percent of screen height.",
	function(oldValue, newValue)
		if (CLIENT and IsValid(nut.gui.score)) then
			nut.gui.score:Remove()
		end
	end,
	{
		form = "Float",
		category = "visual",
		data = {min = 0.3, max = 1}
	}
)

nut.config.add(
	"sbTitle",
	GetHostName(),
	"The title of the scoreboard.",
	function(oldValue, newValue)
		if (CLIENT and IsValid(nut.gui.score)) then
			nut.gui.score:Remove()
		end
	end,
	{
		category = "visual"
	}
)

nut.config.add(
	"sbRecog",
	true,
	"Whether or not recognition is used in the scoreboard.",
	nil,
	{
		category = "characters"
	}
)
