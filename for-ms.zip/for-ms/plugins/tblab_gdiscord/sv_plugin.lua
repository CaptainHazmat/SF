/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/
local PLUGIN = PLUGIN

PLUGIN.extra = { 
	["connect"] = {
		['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
		['discord_webhook'] = "https://discord.com/api/webhooks/1195715531920121887/bofJ7yVmH5FU8tKyeC_uYu8FWP_3nRBNiZ_2n8ak-ZXSUuR0lQic1zT9QJblVHyRUbdz",
		['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
		['channel_id'] = "1195715109994106930"
	},
	["text"] = {
		['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
		['discord_webhook'] = "https://discord.com/api/webhooks/1195715557660565514/9OUPTmFiyiFoXvOehqwWQRr-LB3k-um-VvyoG1v34ym-5Aq3PdIux2R2eBoQ6Y2UVx_W",
		['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
		['channel_id'] = "1195715139261960212"
	},
	["commands"] = {
		['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
		['discord_webhook'] = "https://discord.com/api/webhooks/1195715578720161853/toTSMetiv0v89q5PwZEj9L3YiEoxRjFIeGBy8H5yIOwallynkp5M3a739uWbcXP93RWW",
		['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
		['channel_id'] = "1195715173055479888"
	},
	["kills"] = {
		['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
		['discord_webhook'] = "https://discord.com/api/webhooks/1195715605253337108/tBHUmQqLdi6xHFaNAYpK6rY6Q5lXhCLOZPSM4LcRt4uvQjzUTcX1KZ_jykysU1zdCOSp",
		['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
		['channel_id'] = "1195715204445634671"
	},
	["trade"] = {
		['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
		['discord_webhook'] = "https://discord.com/api/webhooks/1195715660706230344/4qe6sVjEzwnQPAu2yWnaIxTPhObqgiJPxKkCuPCx7-dYQ_HE2ZXxFd5hLQpB0GwRiawd",
		['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
		['channel_id'] = "1195715346011799624"
	},
	["acts"] = {
		['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
		['discord_webhook'] = "https://discord.com/api/webhooks/1195715682294313030/_DEbWZ2jXEFwgGMe2PT5etvhKlYV2qtcWzw_lGCeecH1jjQqRCzv591OTbKVge5qMLLp",
		['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
		['channel_id'] = "1195715501393985638"
	}
		
}
local CHTTP = CHTTP
local strsub = string.sub
local strfind = string.find
local strtrim = string.Trim
local tabtoJSON = util.TableToJSON

GDiscord.sendToDSextra = function(params,strtype)
	if !PLUGIN.extra[strtype] then return end
    CHTTP({
        method = 'POST',
        url = PLUGIN.extra[strtype]['discord_webhook'] .. '?wait=true',
        body = tabtoJSON(params),
        headers = postheader,
        type = "application/json; charset=utf-8"
    })
end

function PLUGIN:OnPlayerInteractItem(client, action, item)
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = client:Nick(),
		['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
		['embeds'] = 
			{ 

				{
					title = "Действие с предметом",
					description = "Предмет: " .. item.name..'\nID предмета: '..item:getID() ..'\nДействие: '..action,                      
					color = 6465586,
					footer = 
					{
						text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
						icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
					}
				} 
			}
	}

	GDiscord.sendToDSextra(params,"acts")
end

function PLUGIN:OnNPCKilled(npc, attacker, inflictor )
	if !attacker:IsPlayer() then return end
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = attacker:Nick(),
		['avatar_url'] = GDiscord.players_avatars_cache[attacker:SteamID64()],
		['embeds'] = 
			{ 

				{
					title = "Убийство",
					description = npc:GetClass(),                      
					color = 6465586,
					footer = 
					{
						text = team.GetName( attacker:Team() ) .. " | " .. attacker:SteamID() ,
						icon_url = GDiscord.players_avatars_cache[attacker:SteamID64()]
					}
				} 
			}
	}

	GDiscord.sendToDSextra(params,"kills") -- connect text commands kills trade acts
end

function PLUGIN:PostEntityTakeDamage(target, dmg)
    if target:IsPlayer() then
		local attacker = dmg:GetAttacker()
		local attackername = "мир"
		if attacker:IsPlayer() then attackername = target:Name() elseif attacker:IsNPC() then attackername = attacker:GetClass() end
		local params = 
		{
			['allowed_mentions'] = { ['parse'] = {} },
			['username'] = target:Nick(),
			['avatar_url'] = GDiscord.players_avatars_cache[target:SteamID64()],
			['embeds'] = 
				{ 

					{
						title = "Урон",
						description = "Получил "..dmg:GetDamage().." урона от " .. attackername,                      
						color = 6465586,
						footer = 
						{
							text = team.GetName( target:Team() ) .. " | " .. target:SteamID() ,
							icon_url = GDiscord.players_avatars_cache[target:SteamID64()]
						}
					} 
				}
		}

		GDiscord.sendToDSextra(params,"kills") -- connect text commands kills trade acts
	end
end

function PLUGIN:DoPlayerDeath( client, attacker, dmg )
	local name = ""
	if attacker:IsPlayer() then 
		name = attacker:Nick()
	else
		name = attacker:GetClass()	
	end
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = client:Nick(),
		['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
		['embeds'] = 
			{ 

				{
					title = "Убит",
					description = "От " .. name ,                      
					color = 6465586,
					footer = 
					{
						text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
						icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
					}
				} 
			}
	}

	GDiscord.sendToDSextra(params,"kills") -- connect text commands kills trade acts
end

function PLUGIN:OnHourSalary(client,old,new,diff) -- Написал 5 отчетов полезных (500$)
	local char = client:getChar()
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = client:Name(),
		['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
		['embeds'] = 
			{ 

				{
					title = "Получение средств",
					description = "Было на счету: "..old.."\nПополнение: "..diff.."\nСейчас на счету: "..new.."\nДенег на руках: "..char:getMoney(),                      
					color = 6465586,
					footer = 
					{
						text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
						icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
					}
				} 
			}
	}

	GDiscord.sendToDSextra(params,"acts") -- connect text commands kills trade acts
end

function PLUGIN:GDiscordShutDown() -- серв лег
	local ip = game.GetIPAddress()
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = "СЕРВЕР",
		['embeds'] = 
			{ 

				{
					title = "Сервер выключен",
					description = "IP: " .. ip ,                      
					color = 11010048,
				} 
			}
	}

	GDiscord.sendToDS(params)	
end

function PLUGIN:InitializedPlugins() -- серв встал
	local ip = game.GetIPAddress()
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = "СЕРВЕР",
		['embeds'] = 
			{ 

				{
					title = "Сервер запустился",
					description = "IP: ".. ip,        --steam://connect/62.122.215.141:27015              
					color = 40447,
				} 
			}
	}

	GDiscord.sendToDS(params)	
end

function nut.command.run(client, command, arguments)
	local cname = command
	local command = nut.command.list[command]
	if (command) then
		-- Run the command's callback and get the return.
		local results = {command.onRun(client, arguments or {})}
		local result = results[1]
		
		local argst = ""
		
		for k,v in pairs(arguments) do argst = argst .. " " .. v end
		if (!command.ignore or false) then
		local params = 
		{
			['allowed_mentions'] = { ['parse'] = {} },
			['username'] = client:Nick(),
			['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
			['embeds'] = 
				{ 
					{
						title = "Команда",
						description = "Использовал команду: ".. cname .. "\n\n Аргументы:"..argst,                      
						color = 6465586,
						footer = 
						{
							text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
							icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
						}
					} 
				}
		}
			
		GDiscord.sendToDSextra(params,"commands") -- connect text commands kills trade acts
		end
		
		-- If a string is returned, it is a notification.
		if (type(result) == "string") then
			-- Normal player here.
			if (IsValid(client)) then
				if (result:sub(1, 1) == "@") then
					client:notifyLocalized(result:sub(2), unpack(results, 2))
				else
					client:notify(result)
				end
			else
				-- Show the message in server console since we're running from RCON.
				print(result)
			end
		end
	end
end

function PLUGIN:OnCharTradeVendor(client, entity, uniqueID, isSellingToVendor, id)
	local stat = ""
	if isSellingToVendor then stat = "Продал" else stat = "Купил" end
	
	local params = 
	{
		['allowed_mentions'] = { ['parse'] = {} },
		['username'] = client:Nick(),
		['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
		['embeds'] = 
			{ 

				{
					title = stat,
					description = nut.item.list[uniqueID].name .. "\nЦена: " .. (nut.item.list[uniqueID].price or 0) .."\nID: " .. (id or "Новый предмет"),                      
					color = 6465586,
					footer = 
					{
						text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
						icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
					}
				} 
			}
	}

	GDiscord.sendToDSextra(params,"trade") -- connect text commands kills trade acts

end

-- function PLUGIN:OnPlayerObserve(client, state)
	-- local noclip = ""
	-- if state then noclip = "Активировал" else noclip = "Деактивировал" end
	-- local params = 
	-- {
		-- ['allowed_mentions'] = { ['parse'] = {} },
		-- ['username'] = client:Nick(),
		-- ['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
		-- ['embeds'] = 
			-- { 

				-- {
					-- title = "Использовал NoClip",
					-- description = noclip,                      
					-- color = 6465586,
					-- footer = 
					-- {
						-- text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
						-- icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
					-- }
				-- } 
			-- }
	-- }

	-- GDiscord.sendToDS(params)
-- end

require('chttp')

local CHTTP = CHTTP
local tabtoJSON = util.TableToJSON

GDiscord.configFactions = {
	[1] = {
			['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
			['discord_webhook'] = "https://discord.com/api/webhooks/1169642882559385670/QDEqjBMJWxk8mwB3x8z0vkwuDO2I1SaO4AqrHMIlMOSfISoJtjb6yNobBB5rqgHOhZ-9",
			['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
			['channel_id'] = "1168142741478309939"
		},
	[2] = {
			['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
			['discord_webhook'] = "https://discord.com/api/webhooks/1169643167197450300/sQ9H_O5NGiotGfa_4yYyGajRbuNGM8ZCHZdFAolmxn9r6gFCrRcz0_o8UzyFW9jXQL77",
			['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
			['channel_id'] = "1168142810025824317"
		},
	}

GDiscord.sendRaportToDS = function(params, id)
	if GDiscord.configFactions[id] then
		CHTTP({
			method = 'POST',
			url = GDiscord.configFactions[id]['discord_webhook'] .. '?wait=true',
			body = tabtoJSON(params),
			headers = postheader,
			type = "application/json; charset=utf-8"
		})
	end
end