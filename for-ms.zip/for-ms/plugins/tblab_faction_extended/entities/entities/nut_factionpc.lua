ENT.Type = "anim"
ENT.PrintName = "Компьютер"
ENT.Author = "Tium"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "NutScript"
ENT.RenderGroup = RENDERGROUP_BOTH

if (SERVER) then
	function ENT:SpawnFunction(client, trace, className)
		if (!trace.Hit or trace.HitSky) then return end

		local ent = ents.Create(className)
		local pos = trace.HitPos
		ent:SetPos(pos)
		ent:Spawn()
		ent:Activate()

		return ent
	end

	function ENT:Initialize()
		self:SetModel("models/props_lab/monitor02.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physicsObject = self:GetPhysicsObject()

		if (IsValid(physicsObject)) then
			physicsObject:Wake()
		end
	end

	function ENT:OnRemove()
	end

	function ENT:Use(activator)
		if activator:getChar() then
			-- net.Start("openraportMenu")
			-- net.Send(activator)
			netstream.Start(activator, 'openraportMenu')
		end
		
	end
else
	function ENT:Draw()
		self:DrawModel()
	end
	
	function ENT:onShouldDrawEntityInfo()
		return true
	end

	function ENT:onDrawEntityInfo(alpha)
		local position = self:LocalToWorld(self:OBBCenter()):ToScreen()
		local x, y = position.x, position.y
		
		surface.SetDrawColor(170,170,170,alpha)
		surface.DrawRect( x+150, y-152, 600, 50)
		
		surface.SetDrawColor(100,100,100,alpha)
		surface.DrawOutlinedRect( x+150, y-152, 600, 50, 3)
		
		surface.SetDrawColor(ColorAlpha(nut.config.get("color"), alpha))
		surface.DrawCircle( x, y, 5)
		
		nut.util.drawText(self.PrintName, x+450, y-142, ColorAlpha(nut.config.get("color"), alpha), 1, 1, nil, alpha * 0.65)
		nut.util.drawText("Небольшой пк, за которым можно позаниматься с базой данных и не только.", x+450, y - 126, ColorAlpha(color_black, alpha), 1, 1, "nutSmallFont", alpha * 0.65)
		surface.SetDrawColor(ColorAlpha(nut.config.get("color"), alpha))
		surface.DrawLine( x+2.5, y-2.5, x+150, y-102)
	end
end