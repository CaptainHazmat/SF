/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

-- util.AddNetworkString("openraportMenu")
-- util.AddNetworkString("returnraporttotxt")

--net.Receive("returnraporttotxt", function(_, client)
    --local text = net.ReadString()
netstream.Hook("returnraporttotxt", function(client, text)
	--if string.len(text) > 2000 then return false end
	local char = client:getChar()
	local dataF = nut.faction.indices[char:getFaction()]
	local rt = dataF.ranktable or "Ranksmain"
	local RankChar = SCHEMA.RanksData[rt].ranks[char:getData("rank",1)]
	local currTime = os.date( "%d/%m/1999 - %H:%M" , os.time() )
	if string.len(text) < 7000 then
		print("1")
		local params = 
		{
			['allowed_mentions'] = { ['parse'] = {} },
			['username'] = char:getName().." | "..RankChar,
			['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
			['embeds'] = 
				{ 

					{
						title = "Отчёт от: " .. currTime,
						description = text,                      
						color = 11010048,
						footer = 
							{
								text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
								icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
							}
					} 
				}
		}
		GDiscord.sendRaportToDS(params,dataF.Gdisord)
		local totalstring = string.gsub(text," ","")
		if char:getData("CanRaport", false) and string.len(totalstring)/2 > 400 then
			local AddSalary = math.Round((SCHEMA.RanksData[rt].salary[char:getData("rank",1)])/4,0)
			char:setData("CanRaport", false)
			local CharSalary = char:getData("CharSalary",0)
			char:setData("CharSalary",CharSalary+AddSalary)
			client:notify("От комании получена зарплата в размере: "..AddSalary.."$")
			hook.Run("OnRaport", client)
		end
		client:notify("Рапорт отправлен")
	elseif string.len(text) > 7000 and string.len(text) < 14000 then
		local params = 
		{
			['allowed_mentions'] = { ['parse'] = {} },
			['username'] = char:getName().." | "..RankChar,
			['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
			['embeds'] = 
				{ 

					{
						title = "Отчёт от: " .. currTime,
						description = string.sub(text,0,string.len(text)/2),                      
						color = 11010048,
					} 
				},
				
		}
		GDiscord.sendRaportToDS(params,dataF.Gdisord)
		params = 
		{
			['allowed_mentions'] = { ['parse'] = {} },
			['username'] = char:getName().." | "..RankChar,
			['avatar_url'] = GDiscord.players_avatars_cache[client:SteamID64()],
			['embeds'] = 
				{ 

					{
						description = string.sub(text,string.len(text)/2 + 1),                      
						color = 11010048,
						footer = 
							{
								text = team.GetName( client:Team() ) .. " | " .. client:SteamID() ,
								icon_url = GDiscord.players_avatars_cache[client:SteamID64()]
							}
					} 
				}
		}
		GDiscord.sendRaportToDS(params,dataF.Gdisord)
		local totalstring = string.gsub(text," ","")
		if char:getData("CanRaport", false) and string.len(totalstring)/2 > 400 then
			local AddSalary = math.Round((SCHEMA.RanksData[rt].salary[char:getData("rank",1)])/4,0)
			char:setData("CanRaport", false)
			local CharSalary = char:getData("CharSalary",0)
			char:setData("CharSalary",CharSalary+AddSalary)
			client:notify("От комании получена зарплата в размере: "..AddSalary.."$")
		end
		client:notify("Рапорт отправлен")
	end
end)
