/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

local PANEL = {}

local ScrW, ScrH = ScrW(), ScrH()
local limit = 7000
function PANEL:Init()

    if IsValid(nut.gui.raportmenu) then
        nut.gui.raportmenu:Remove()
    end
    nut.gui.raportmenu = self

    self.contents = {
        text = "",
        bigText = "",
        duration = 3,
        blackBars = true,
        music = true,
        color = color_white
    }

    local textEntryTall = ScrH*0.045

    self:SetSize(ScrW*0.6, ScrH*0.6)
    self:Center()
    self:MakePopup()
    self:SetTitle("Рапопт")

    local textLabel = self:Add("DLabel")
    textLabel:SetText("Заполнил:")
    textLabel:SetFont("nutSmallFont")
    textLabel:SetTextColor(nut.config.get("color", Color(75, 119, 190)))
    textLabel:Dock(TOP)
    textLabel:DockMargin( 20, 5, 20, 0 )
    textLabel:SizeToContents()
	
	
	local faction = nut.faction.indices[LocalPlayer():Team()]
	local factranksys = faction.ranktable or "Ranksmain"
	local RT = SCHEMA.RanksData[factranksys]
	local rank = LocalPlayer():getChar():getData("rank",1)
    local textLabel2 = self:Add("DLabel")
    textLabel2:SetText(LocalPlayer():Name() .. " | " .. "Ранг: " .. RT.ranks[rank] .. " - " .. RT.translate[rank])
    textLabel2:SetFont("nutMediumFont")
    textLabel2:SetTextColor(Color(255, 255, 255))
    textLabel2:Dock(TOP)
    textLabel2:DockMargin( 20, 5, 20, 0 )
    textLabel2:SizeToContents()

    local bigTextLabel = self:Add("DLabel")
    bigTextLabel:SetText("Текст рапорта:")
    bigTextLabel:SetFont("nutSmallFont")
    bigTextLabel:SetTextColor(nut.config.get("color", Color(75, 119, 190)))
    bigTextLabel:Dock(TOP)
    bigTextLabel:DockMargin( 20, 5, 20, 0 )
    bigTextLabel:SizeToContents()

	local count = self:Add("DLabel")
    count:SetText("0/"..limit)
    count:SetFont("nutSmallFont")
    count:SetTextColor(Color(255, 255, 255))
    count:Dock(TOP)
    count:DockMargin( 20, 5, 20, 0 )
    count:SizeToContents()

	local bigTextEntry = self:Add("DTextEntry")
    bigTextEntry:SetFont("nutMediumFont")
    bigTextEntry:Dock(TOP)
	bigTextEntry:SetSize(ScrW*0.3, ScrH*0.3)
    bigTextEntry:DockMargin( 20, 5, 20, 0 )
	bigTextEntry:SetTextColor(Color(0,0,0))
	bigTextEntry:SetMultiline(true)
	bigTextEntry:SetEditable(true)		
	bigTextEntry:SetPaintBackground(false)
	bigTextEntry:SetEnterAllowed(false)
	bigTextEntry:SetUpdateOnType(true)
	bigTextEntry:SetDrawLanguageID( false )
	bigTextEntry:SetTooltip("РП отчет об операциях, патрулях, событиях и прочем.\nДату указывать не нужно\nИмя указвать не нужно\nПридерживайтесь правил отчетов")
	bigTextEntry.OnValueChange = function(this, value)
		local str = string.gsub(value, " ","а")
		count:SetText((string.len(str)/2).."/"..limit)
		self.contents.bigText = value
    end

    local quitButton = self:Add("DButton")
    quitButton:Dock(BOTTOM)
    quitButton:DockMargin( 20, 5, 20, 0 )
    quitButton:SetText("Отмена")
    quitButton:SetTextColor(Color(255,0,0))
    quitButton:SetFont("nutSmallFont")
    quitButton:SetTall(ScrH*0.05)
    quitButton.DoClick = function()
        self:Remove()
    end

    local postButton = self:Add("DButton")
    postButton:Dock(BOTTOM)
    postButton:DockMargin( 20, 5, 20, 0 )
    postButton:SetText("Записать")
    postButton:SetTextColor(color_white)
    postButton:SetFont("nutSmallFont")
    postButton:SetTall(ScrH*0.05)
    postButton.DoClick = function()
        if not (self.contents and (self.contents.text or self.contents.bigText)) then nut.util.notify("Чет, ебануло, еще раз!") return end
        if  self.contents.text == "" and self.contents.bigText == "" then nut.util.notify("Где текст?") return end
		if (string.len(self.contents.bigText)/2) > limit then nut.util.notify("Перебор текста на "..string.len(self.contents.bigText)-limit) return end
		
        -- net.Start("returnraporttotxt")
            -- net.WriteString(self.contents.bigText)
        -- net.SendToServer()
		netstream.Start("returnraporttotxt", self.contents.bigText)
        self:Remove()
    end
    self:SizeToContents()

end

vgui.Register("raportMenu", PANEL, "DFrame")

-- net.Receive("openraportMenu", function()
	-- vgui.Create("raportMenu")
-- end)
netstream.Hook("openraportMenu", function()
	vgui.Create("raportMenu")
end)