/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/
PLUGIN.name = "TimeBreaker Admin Menu"
PLUGIN.author = "_tium_"
PLUGIN.desc = ""

local PLUGIN = PLUGIN
if SERVER then
	util.AddNetworkString("openadminmenu")
	
	netstream.Hook("gcd", function(client, target)
		local data = target:getChar():getData()
		netstream.Start(client, "recieveData", data)
	end)
end
-- local IncludeFiles = {}
-- for k, v in ipairs(IncludeFiles) do nut.util.include(v) end

nut.command.add("adminmenu", {
    adminOnly = true,
	onRun = function(client)
		net.Start("openadminmenu")
        net.Send(client)
	end
})

PLUGIN.commands = {
	["charsetmodel"] = {
		needarg = true,
		desc = "Смена модели",
		argamount = 1,
	},
	
	["charsetname"] = {
		needarg = true,
		desc = "Смена имени",
		argamount = 1,
	},
	
	["arank"] = {
		needarg = true,
		desc = "Установить ранг",
		argamount = 1,
	},
	
	["adminsearch"] = {
		needarg = false,
		desc = "Открыть инвентарь",
		argamount = 0,
	},
	
	["givepravaup"] = {
		needarg = false,
		desc = "Выдать права на воздушный транспорт",
		argamount = 0,
	},
	
	["givepravacar"] = {
		needarg = false,
		desc = "Выдать права на наземный транспорт",
		argamount = 0,
	},
	
	["removepravaup"] = {
		needarg = false,
		desc = "Забрать права на воздушный транспорт",
		argamount = 0,
	},
	
	["removepravacar"] = {
		needarg = false,
		desc = "Забрать права на воздушный транспорт",
		argamount = 0,
	},
	
	["chargetmodel"] = {
		needarg = false,
		desc = "Что за модель у игрока?",
		argamount = 0,
	},
	
	["charsetattrib"] = {
		needarg = true,
		desc = "Установить атрибут (атриб-уровень)",
		argamount = 2,
	},
	
	["charaddattrib"] = {
		needarg = true,
		desc = "Добавить атрибут (атриб-уровень)",
		argamount = 2,
	},
	
	["charkick"] = {
		needarg = false,
		desc = "Кик из персонажа",
		argamount = 0,
	},
	
	["charban"] = {
		needarg = false,
		desc = "Забанить персонажа",
		argamount = 0,
	},
	
	["charsetmoney"] = {
		needarg = true,
		desc = "Установить деньги игроку",
		argamount = 1,
	},
	
	["charaddmoney"] = {
		needarg = true,
		desc = "Добавить деньги игроку",
		argamount = 1,
	},
	
	["plytransfer"] = {
		needarg = true,
		desc = "Переместить игрока во фракцию",
		argamount = 1,
	},
	

}