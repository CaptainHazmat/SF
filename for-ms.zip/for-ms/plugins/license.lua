/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2028 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

PLUGIN.name = "SavePlugin"
PLUGIN.author = "Tium"
PLUGIN.desc = "Saves some data."

nut.command.add("givepravaup", {
	syntax = "<string name>",
	onCheckAccess = function(client)
		local char = client:getChar()
		if char:hasFlags("F") then
			return true
		else
			return false
		end
	end,
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])
		if(IsValid(target) and target:getChar()) then
			local char = target:getChar()
			char:setData("pravaup", true)
			--target:setNetVar("pravaup",true)
			client:notify("Вы выдали лицензию пилота для " .. target:Name())
		else
			client:notify("Не найдено.")
		end
	end
})

nut.command.add("givepravacar", {
	syntax = "<string name>",
	onCheckAccess = function(client)
		local char = client:getChar()
		if char:hasFlags("F") then
			return true
		else
			return false
		end
	end,
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])
		if(IsValid(target) and target:getChar()) then
			local char = target:getChar()
			char:setData("pravadown", true)
			--target:setNetVar("pravadown",true)
			client:notify("Вы выдали водительскеин права для " .. target:Name())
		else
			client:notify("Не найдено.")
		end
	end
})

nut.command.add("removepravaup", {
	syntax = "<string name>",
	onCheckAccess = function(client)
		local char = client:getChar()
		if char:hasFlags("F") then
			return true
		else
			return false
		end
	end,
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])
		if(IsValid(target) and target:getChar()) then
			target:getChar():setData("pravaup", false)
			--target:SetNWBool("pravaup",false)
			client:notify("Вы забрали лицензию пилота у " .. target:Name())
		else
			client:notify("Не найдено.")
		end
	end
})

nut.command.add("removepravacar", {
	syntax = "<string name>",
	onCheckAccess = function(client)
		local char = client:getChar()
		if char:hasFlags("F") then
			return true
		else
			return false
		end
	end,
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])
		if(IsValid(target) and target:getChar()) then
			target:getChar():setData("pravadown", false)
			client:notify("Вы забрали водительские права у " .. target:Name())
		else
			client:notify("Не найдено.")
		end
	end
})

if SERVER then
	function PLUGIN:simfphysOnEngine(weh, stat)
		if weh:GetDriver() == nil then return end
		local ply = weh:GetDriver()
		if !IsValid(ply) and !ply:IsPlayer() then return end
		if ply:getChar() then
			if ply:getChar():getData("pravadown",false) then 
				return false
			elseif !ply:getChar():getData("pravadown",false) then
				return true
			end
		else
			return true
		end
	end

end