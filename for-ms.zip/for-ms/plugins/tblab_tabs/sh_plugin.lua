/*--------------------------------------------------
	=============== TB.Lab scrips ===============
	*** Copyright (c) 2012-2024 by Tium, All rights reserved. ***

	██████████  █████   	██		 █████   █████
		██ 	    ██	 █   	██		██   ██  ██	  █
		██      ██████   	██		██   ██  ██████
		██ 	  	██   █    	██		███████	 ██   █
		██   	█████  ██  	██████  ██   ██  █████

--------------------------------------------------*/

local PLUGIN = PLUGIN
PLUGIN.name = "Character Customization"
PLUGIN.desc = "Panel that allows to change bodygroups and skins"
PLUGIN.author = "Tium"

nut.util.include("cl_hooks.lua")

if (SERVER) then
	netstream.Hook("nutBodygroupSend", function(client, index, value)
		local character = client:getChar()
		local groups = character:getData("groups", {})
		groups[index] = value
		character:setData("groups", groups)
		client:SetBodygroup(index, value or 0)
	end)

	netstream.Hook("nutSkinSend", function(client, skinmodel)
		local character = client:getChar()
		character:setData("skin", skinmodel)
		client:SetSkin(skinmodel or 0)
	end)
end 

nut.command.add("extramodel", {
	syntax = "[number] [number]",
	onRun = function(client, arguments)
		local what = tonumber(arguments[1])
		local value = tonumber(arguments[2])
		local modelT 
		if client:isFemale() then modelT = SCHEMA.ExtraModel["female"][value] else modelT = SCHEMA.ExtraModel["male"][value] end
		local clientModels = client:getChar():getData("EM",{})
		if what == 1 then 
			if !modelT.canBuy then return false end
			if !clientModels[value] then
				if client:getChar():getMoney() >= modelT.money then
					client:getChar():setMoney(client:getChar():getMoney() - modelT.money)
					clientModels[value] = true
					client:getChar():setData("EM",clientModels)
					client:notify("Вы купили модель под номером - ".. value)
				else
					client:notify("Нехватает денег")
				end
			else
				client:notify("Модель уже куплена")
			end
		elseif what == 2 then 
			for k,v in pairs(ents.FindInSphere(client:GetPos(),100)) do
				if v:GetClass() == "nut_wardrobe" or client:IsAdmin() then
					if clientModels[value] or (value == 0) then
						if value == 0 then
							client:getChar():setData("groups", {})
							client:getChar():setModel(client:getChar():getData("SavedModel",client:getChar():getModel()))
							client:getChar():setData("SavedModel",nil)
							client:notify("Модель установлена")
						else	
							client:getChar():setData("groups", {})
							client:getChar():setData("SavedModel",client:getChar():getModel())
							client:getChar():setModel(modelT.model)
							client:notify("Модель установлена")
						end
					else
						client:notify("Модель не куплена")
					end
					break
				end
			end
		end
	end,
})

nut.command.add("emgive", {
	adminOnly = true,
	syntax = "<string name> [number model]",
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])
		local value = tonumber(arguments[2])
		local modelT 
		if target:isFemale() then modelT = SCHEMA.ExtraModel["female"][value] else modelT = SCHEMA.ExtraModel["male"][value] end
		if (IsValid(target) and target:IsPlayer() and target:getChar()) and modelT then
			local targetModels = target:getChar():getData("EM",{})
			targetModels[value] = true
			target:getChar():setData("EM",targetModels)
			client:notify("Вы выдали модель "..target:getChar():getName().." под номером - ".. value)
			target:notify("Вам выдали модель - ".. value)
		else
			client:notify("Где-то ошибка")
		end
	end
})

nut.command.add("emtake", {
	adminOnly = true,
	syntax = "<string name> [number model]",
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])
		local value = tonumber(arguments[2])
		local modelT 
		if target:isFemale() then modelT = SCHEMA.ExtraModel["female"][value] else modelT = SCHEMA.ExtraModel["male"][value] end
		if (IsValid(target) and target:IsPlayer() and target:getChar()) and modelT then
			local targetModels = target:getChar():getData("EM",{})
			if targetModels[value] == true then
				targetModels[value] = false
				target:getChar():setData("EM",targetModels)
				client:notify("Вы забрали модель "..target:getChar():getName().." под номером - ".. value)
				target:notify("У вас забрали модель - ".. value)
			end
		else
			client:notify("Где-то ошибка")
		end
	end
})