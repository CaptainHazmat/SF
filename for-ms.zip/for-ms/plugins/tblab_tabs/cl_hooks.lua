local PLUGIN = PLUGIN

hook.Add("CreateMenuButtons", "nutCharacterCustomizer", function(tabs)
	tabs["Кастомизация"] = function(container)
		container:Add("nutCharacterCustomizer")
	end
end)

hook.Add("CreateMenuButtons", "nutExtraModels", function(tabs)
	tabs["Модели"] = function(container)
		container:Add("nutExtraModels")
	end
end)