local PANEL = {}
local font = "menu_30" -- кнопки слева
local font2 = "menu_30" -- кнопки справа
-- Called when the panel is initialized.
function PANEL:Init()
	local tbl
	if LocalPlayer():isFemale() then tbl = SCHEMA.ExtraModel["female"] else tbl = SCHEMA.ExtraModel["male"] end
	local BodygroupData = {}
	local skinmodel = nil
	self:SetSize(ScrW()/1.8, ScrH()/1.7)
	self:Center()

	self.left = vgui.Create( "DScrollPanel", self )
	self.left:Dock( LEFT )
	self.left:SetSize( self:GetWide() / 3 - 7 , self:GetTall() /3)
	self.left:SetPaintBackground( true )
	self.left:DockMargin( 0, 0, 4, 0 )
	self.left.Paint = function( self, w, h )
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/LINE_desc_2.png"))
		surface.DrawTexturedRect(2, 0, 2, #tbl*((ScrH() * 0.05)+10) - 10)
	end
	local curModel = 0
	
    --------------------------------правая сторона -------------------------
	self.bottom = self:Add("DPanel")
	self.bottom:Dock( BOTTOM )
	self.bottom:SetSize( 25, 40 )
	self.bottom:DockMargin( 0, 5, 0, 0 )
	self.bottom.Paint = function( self, w, h ) end
	
	
	self.bottom.button1 = self.bottom:Add("DButton")
	self.bottom.button1:Dock(LEFT)
	self.bottom.button1:SetSize( self:GetWide()/3 - 10 , 40)
	self.bottom.button1.color = Color(0,0,0,100)
	self.bottom.button1:SetText("")
	
	local textlabel1 = self.bottom.button1:Add("DLabel")
	textlabel1:SetColor(color_white)
	textlabel1:SetFont(font2)
	textlabel1:SetContentAlignment(5)
	textlabel1:SetText("Выберите модель")
	textlabel1:Dock(FILL)
	
	self.bottom.button1.Paint = function( self, w, h ) 
		surface.SetDrawColor(self.color)
		surface.DrawRect(0, 0, w, h)
	end
	
	self.bottom.button2 = self.bottom:Add("DButton")
	self.bottom.button2:Dock(RIGHT)
	self.bottom.button2:SetSize( self:GetWide()/3 - 10 , 40)
	self.bottom.button2.color = Color(0,0,0,100)
	self.bottom.button2:SetText("")
	
	local textlabel2 = self.bottom.button2:Add("DLabel")
	textlabel2:SetColor(color_white)
	textlabel2:SetFont(font2)
	textlabel2:SetText("Сбросить модель")
	textlabel2:SetContentAlignment(5)
	textlabel2:Dock(FILL)
	
	self.bottom.button2.Paint = function( self, w, h ) 
		surface.SetDrawColor(self.color)
		surface.DrawRect(0, 0, w, h)
	end
	
	characterModel = vgui.Create( "nutModelPanel", self, "characterModel" )
	characterModel:SetPos(0, 0)
	characterModel:SetSize( self:GetWide() / 1.50 , self:GetTall() /3)
	characterModel:SetModel(LocalPlayer():GetModel())
	characterModel:SetFOV(80)
	characterModel:Dock(RIGHT)
	
	self.bottom.button1.DoClick = function(s)
		surface.PlaySound("tbmw/menuclick.wav")
		if textlabel1:GetText() != "Установить" then
			nut.command.send("extramodel", 1, curModel)
		elseif textlabel1:GetText() == "Установить" then
			nut.command.send("extramodel", 2, curModel)
		end
	end
	
	self.bottom.button2.DoClick = function(s)
		surface.PlaySound("tbmw/menuclick.wav")
		curModel = 0
		nut.command.send("extramodel", 2, 0)
		characterModel:SetModel(LocalPlayer():getChar():getData("SavedModel",LocalPlayer():getChar():getModel()))
		textlabel1:SetText("Выберите модель")
		self.bottom.button1.color = Color(0,0,0,100)
	end
	---------------------------кнопки----------------------------
	for k,v in SortedPairs(tbl) do
		local button = self.left:Add("DButton")
		button:Dock(TOP)
		button:DockMargin(15,0,0,10)
		button:SetTall(ScrH() * 0.05)
		button:SetText("")
		button.OnCursorEntered = function(s)
			surface.PlaySound("tbmw/menuswipe.wav")
		end
		local textlabel = button:Add("DLabel")
		textlabel:SetColor(color_white)
		textlabel:SetFont(font)
		textlabel:SetText(k.. " - ".. v.money..'$')
		textlabel:SetContentAlignment(5)
		textlabel:Dock(FILL)
			
		button.DoClick = function(s)
			surface.PlaySound("tbmw/menuclick.wav")
			curModel = k
			characterModel:SetModel(v.model)
			local exModels = LocalPlayer():getChar():getData("EM",{})
			if exModels[curModel] then
				self.bottom.button1.color = Color(17,204,0,210)
				textlabel1:SetText("Установить")
			elseif !v.canBuy then 
				self.bottom.button1.color = Color(255,0,0,100)
				textlabel1:SetText("Не куплена")
			else
				if v.money <= LocalPlayer():getChar():getMoney() then
					self.bottom.button1.color = Color(17,204,0,210)
					textlabel1:SetText("Купить")
				else
					self.bottom.button1.color = Color(255,0,0,100)
					textlabel1:SetText("Нехватает денег")
				end
			end
		end
	end
end

vgui.Register("nutExtraModels", PANEL, "EditablePanel")