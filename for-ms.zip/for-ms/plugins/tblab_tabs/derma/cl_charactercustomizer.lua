local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	local BodygroupData = {}
	local skinmodel = nil
	self:SetSize(ScrW()/1.8, ScrH()/1.7)
	self:Center()

	--self.back = self.Add("DPanel")
	
	
	
	self.bottom = vgui.Create( "DButton", self, "bottom" )
	self.bottom:Dock( BOTTOM )
	self.bottom:SetSize( 25, 40 )
	self.bottom:SetColor(Color(0,0,0))
	self.bottom:SetTextColor(color_white)
	--self.bottom:SetMaterial(Material("vgui/ramka.png"))
	self.bottom:SetText( "ПОДТВЕРДИТЬ" )
	self.bottom:SetFont("nutMediumFont")
	self.bottom:DockMargin( 0, 5, 0, 0 )
	function self.bottom:DoClick()
		local bodygroup = LocalPlayer():GetBodyGroups()
		for k, v in pairs( bodygroup ) do
			local index = v.id
			local value = BodygroupData[v.id]

			if (index > -1) then
				if (value and value < 1) then
					value = nil
				end

				netstream.Start("nutBodygroupSend", index, value)
			end
		end
		netstream.Start("nutSkinSend", skinmodel)
	end

	characterModel = vgui.Create( "nutModelPanel", self, "characterModel" )
	characterModel:SetPos(0, 0)
	characterModel:SetSize( self:GetWide() / 1.30 - 7 , self:GetTall() /3)
	characterModel:SetModel(LocalPlayer():GetModel())
	local data = LocalPlayer():getChar():getData("groups", {})
	PrintTable(data)
	if data then
		for k,v in pairs(data) do
			characterModel.Entity:SetBodygroup(k, v or 0)
			BodygroupData[k] = v
		end
	end
	characterModel:SetFOV(70)
	characterModel:Dock(RIGHT)

	self.left = vgui.Create( "DScrollPanel", self )
	self.left:Dock( LEFT )
	self.left:SetSize( self:GetWide() / 3 - 7 , self:GetTall() /3)
	self.left:SetPaintBackground( true )
	self.left:DockMargin( 0, 0, 4, 0 )

		self.labelbody = vgui.Create( "DLabel", self, "labelbody" )
		self.labelbody:SetText("Бодигрупы")
		self.labelbody:SetFont("nutSmallFont")
		self.labelbody:SetSize( 36, 36 )
		self.labelbody:Dock( TOP )
		self.left:AddItem( self.labelbody )

		local bodygroup = LocalPlayer():GetBodyGroups()
		local bodygrouptest = {}
		--PrintTable(bodygrouptest)
		--PrintTable(bodygroup)
		for k, v in pairs( bodygroup ) do
			if k > 1 and #(v.submodels) > 0 then
				self.but = vgui.Create( "DComboBox", self, "but" )
				self.but:SetValue( v.name )
				self.but:SetFont("nutSmallFont")
				self.but:SetSize( 36, 36 )
				self.but:Dock( TOP )
				self.but.Think = function(this)
					this:SetText(v.name .. "   -    ".. (data[v.id] or BodygroupData[v.id] or 0))
				end
				if bodygrouptest[k-1] then
					self.but:SetValue( bodygrouptest[k-1] )
					table.insert(BodygroupData, v.id, bodygrouptest[k-1])
					characterModel.Entity:SetBodygroup(v.id, bodygrouptest[k-1])
				end
				-- print(k)
				-- PrintTable(v.submodels)
				-- print("-----")
				for x, y in pairs( v.submodels ) do
					self.but:AddChoice( x , x )
				end
				function self.but:OnSelect(self, index, value)
					if (BodygroupData[v.id]) then
						table.remove(BodygroupData, v.id)
						table.insert(BodygroupData, v.id, value)
						characterModel.Entity:SetBodygroup(v.id, value)
					else
						table.insert(BodygroupData, v.id, value)
						characterModel.Entity:SetBodygroup(v.id, value)
					end
				end 
				self.left:AddItem( self.but )
			end
		end

		self.labelskin = vgui.Create( "DLabel", self, "labelskin" )
		self.labelskin:SetText( "Скин" )
		self.labelskin:SetFont("nutSmallFont")
		self.labelskin:SetSize( 36, 36 )
		self.labelskin:DockMargin( 0, 20, 0, 0 )
		self.labelskin:Dock( TOP )
		self.left:AddItem( self.labelskin )

		self.butskin = vgui.Create( "DComboBox", self, "butskin" )
		self.butskin:SetValue( LocalPlayer():getChar():getData("skin", 0) or "Skin" )
		characterModel.Entity:SetSkin(LocalPlayer():getChar():getData("skin", 0) or "Skin")
		self.butskin:SetFont("nutSmallFont")
		self.butskin:SetSize( 36, 36 )
		self.butskin:SetSortItems( false )
		self.butskin:Dock( TOP )
		local skcount = LocalPlayer():SkinCount()
		for i=0,skcount do
			self.butskin:AddChoice( i )
		end
		function self.butskin:OnSelect(self, index, value)
			skinmodel = index
			characterModel.Entity:SetSkin(index)
		end
		self.left:AddItem( self.butskin )
end

vgui.Register("nutCharacterCustomizer", PANEL, "EditablePanel")