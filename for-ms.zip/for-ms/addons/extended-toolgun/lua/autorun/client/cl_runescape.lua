--[[
	happy april fools 2017!

	after last year's april fools i was rather convinced that i wanted to do it again.
	it was so fun, everyone flipped shit over something so harmless. i tried to be a little
	less intrusive this time, hopefully less people will act as though i've done something
	to personally attack them.

	as always this payload will stop executing after april 1st.

	credits:
	me / uselessghost: the code you see below
	nathan p: the runescape uf font
	blazingdash99: the p hat models
	jagex: "harmony", the music used in this code
]]

if os.date( "%x" ) ~= "04/01/17" then return end

surface.CreateFont( "RuneScape", {
	font = "RuneScape UF",
	size = 32,
	antialias = false
} )

local CHAT_SCALE = 3
local CHAT_DURATION = 8

local COLOR_YELLOW = Color( 255, 242, 0 )
local COLOR_WHITE = Color( 255, 255, 255 )
local COLOR_RED = Color( 255, 0, 0 )
local COLOR_GREEN = Color( 0, 255, 0 )
local COLOR_DARKGREEN = Color( 0, 125, 0 )
local COLOR_BLUE = Color( 0, 0, 255 )
local COLOR_CYAN = Color( 0, 255, 255 )
local COLOR_PURPLE = Color( 255, 0, 255 )

local COLOR_DEFAULT = COLOR_YELLOW

local ColorEffects = {
	white = function() return COLOR_WHITE end,
	red = function() return COLOR_RED end,
	green = function() return COLOR_GREEN end,
	cyan = function() return COLOR_CYAN end,
	purple = function() return COLOR_PURPLE end,

	glow1 = function() return HSVToColor( SysTime() * 360 * 0.1 % 360, 1, 1 ) end,
	glow2 = function() return Color( ( ( math.sin( SysTime() * math.pi ) + 1 ) / 2 ) * 255, 0, ( ( math.sin( SysTime() * math.pi + math.pi ) + 1 ) / 2 ) * 255 ) end, -- red to purple 
	glow3 = function() return Color( ( ( math.sin( SysTime() * math.pi ) + 1 ) / 2 ) * 255, 255, ( ( math.sin( SysTime() * math.pi ) + 1 ) / 2 ) * 255 ) end, -- red to purple 

	flash1 = function() return math.floor( SysTime() * 2 ) % 2 == 0 and COLOR_YELLOW or COLOR_RED end,
	flash2 = function() return math.floor( SysTime() * 2 ) % 2 == 0 and COLOR_BLUE or COLOR_CYAN end,
	flash3 = function() return math.floor( SysTime() * 2 ) % 2 == 0 and COLOR_GREEN or COLOR_DARKGREEN end,
}

local MoveEffects = {
	wave = function( x, y, i, char )
		return x, y + math.sin( SysTime() * math.pi + i * 0.25 ) * 16
	end,
	wave2 = function( x, y, i, char )
		return x + math.sin( SysTime() * math.pi * 2 + i * 0.25 + math.pi ) * 16, y + math.sin( SysTime() * math.pi * 2 + i * 0.25 ) * 16
	end
}

local function DrawRuneScapeText( text, x, y, color_effect, move_effect )
	--local mat = Matrix()
	--mat:Translate( Vector( x, y, 0 ) )
	--mat:Scale( Vector( 1, 1, 1 ) * CHAT_SCALE )

	--cam.PushModelMatrix( mat )
	local w, h = 0, 0

	for i = 1, #text do
		local char_w, char_h = surface.GetTextSize( text[ i ] )

		w = w + char_w + 2

		if char_h < h then
			h = char_h
		end
	end

	x = x - w / 2
	y = y - h / 2

	for i = 1, #text do
		local char = text[ i ]

		local mod_x, mod_y = x, y

		if move_effect then
			mod_x, mod_y = move_effect( x, y, i, char )
		end

		local color = color_effect and color_effect( i, char ) or COLOR_DEFAULT

		draw.SimpleText( char, "RuneScape", mod_x + 2, mod_y + 2, color_black )
		draw.SimpleText( char, "RuneScape", mod_x, mod_y, color )

		surface.SetFont( "RuneScape" )
		local w, h = surface.GetTextSize( char )

		x = x + w + 2
	end

	--cam.PopModelMatrix()
end

local PartyHats = {
	"models/black_partyhat/black_partyhat.mdl",
	"models/blue_partyhat/blue_partyhat.mdl",
	"models/green_partyhat/green_partyhat.mdl",
	"models/pink_partyhat/pink_partyhat.mdl",
	"models/red_partyhat/red_partyhat.mdl",
	"models/white_partyhat/white_partyhat.mdl",
	"models/yellow_partyhat/yellow_partyhat.mdl",
}

hook.Add( "PostPlayerDraw", "DrawPartyHats", function( pl )
	if not pl.PartyHat then
		pl.PartyHat = ClientsideModel( table.Random( PartyHats ) )
		pl.PartyHat:SetModelScale( 0.75, 0 )
		pl.PartyHat:SetNoDraw( true )
	end

	local pos = pl:GetPos() + Vector( 0, 0, 50 )
	local ang = Angle( 0, 0, 0 )

	local att = pl:LookupAttachment( "eyes" )
	if att > 0 then
		local posang = pl:GetAttachment( att )

		ang = posang.Ang
		pos = posang.Pos

		pos = pos - ang:Up() * 22
		pos = pos - ang:Forward() * 3
	end

	pl.PartyHat:SetPos( pos )
	pl.PartyHat:SetAngles( ang )
	pl.PartyHat:DrawModel()
end )

hook.Add( "OnPlayerChat", "RuneScapeChat", function( pl, text, team )
	if not IsValid( pl ) or team then return end

	pl.OverheadChatColorEffect = nil
	pl.OverheadChatMoveEffect = nil

	local i = 1
	while #text > i do
		local sub = string.sub( text, 1, i )
		local match = string.match( sub, "^(%w+):$" )

		if match then
			if ColorEffects[ match ] or MoveEffects[ match ] then
				if ColorEffects[ match ] then
					pl.OverheadChatColorEffect = ColorEffects[ match ]
				elseif MoveEffects[ match ] then
					pl.OverheadChatMoveEffect = MoveEffects[ match ]
				end

				text = string.sub( text, i + 1 )
				i = 0
			end
		end

		i = i + 1
	end

	pl.OverheadChat = text
	pl.OverheadChatTimer = CurTime() + CHAT_DURATION

	if math.random() > 0.5 then
		pl.OverheadChatColorEffect = table.Random( ColorEffects )
	end

	if math.random() > 0.5 then
		pl.OverheadChatMoveEffect = table.Random( MoveEffects )
	end
end )

hook.Add( "HUDPaint", "DrawRuneScapeChat", function()
	for _, pl in ipairs( player.GetAll() ) do
		if pl:GetPos():Distance( EyePos() ) < 1000 then
			if pl.OverheadChatTimer and pl.OverheadChatTimer > CurTime() then
				local text = pl.OverheadChat

				local color_effect = pl.OverheadChatColorEffect
				local move_effect = pl.OverheadChatMoveEffect

				local pos = pl:GetPos() + Vector( 0, 0, 100 )

				local att = pl:LookupAttachment( "eyes" )
				if att > 0 then
					pos = pl:GetAttachment( att ).Pos + Vector( 0, 0, 16 )
				end

				local screen_pos = pos:ToScreen()
				local x, y = screen_pos.x, screen_pos.y

				DrawRuneScapeText( text, x, y, color_effect, move_effect )
			end
		end
	end
end )

hook.Add( "InitPostEntity", "PlayRuneScapeMusic", function()
	chat.AddText( "Welcome to RuneScape." )
	sound.PlayFile( "sound/harmony.ogg", "", function( station )
		if IsValid( station ) then station:Play() end
	end )
end )