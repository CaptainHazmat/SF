

-- AddCSLuaFile()

-- ENT.Base 			= "base_gmodentity"
-- ENT.PrintName			= "Resized Ragdoll Physobj"
-- ENT.Author			= ""

-- ENT.Spawnable			= false
-- ENT.AdminSpawnable		= false

-- //ENT.Type			= "ai" //this actually fixes resized ragdolls not making phys impact sounds, but breaks a whole bunch of random physics stuff, so it's not worth the trouble
-- //ENT.AutomaticFrameAdvance	= true
-- ENT.RenderGroup			= RENDERGROUP_TRANSLUCENT

-- //for killfeed notices
-- if CLIENT then
	-- language.Add("prop_resizedragdoll_physobj", "Ragdoll")
	-- killicon.AddAlias("prop_resizedragdoll_physobj", "prop_physics")
-- end




-- if CLIENT then

	-- function ENT:BabysitClientsidePhysobj(phys)

		-- phys:EnableMotion(false) //not sure if it's necessary to do this again after spawning it, but keep its motion disabled just in case
		-- phys:Sleep() //the clientside physobj likes to break things unless it's asleep
		-- phys:SetPos(self:GetPos())
		-- phys:SetAngles(self:GetAngles())

	-- end

	-- function ENT:PhysicsUpdate()

		-- local phys = self:GetPhysicsObject()
		-- if !IsValid(phys) then return end
		-- if !phys:IsAsleep() then self:BabysitClientsidePhysobj(phys) end

		-- //A physobj moved, so tell the parent to recompute the ragdoll bounds
		-- self.RagdollParent.RagdollBoundsFresh = nil

	-- end

	-- function ENT:CalcAbsolutePosition()

		-- local phys = self:GetPhysicsObject()
		-- if !IsValid(phys) then return end
		-- self:BabysitClientsidePhysobj(phys)

		-- //A physobj moved, so tell the parent to recompute the ragdoll bounds
		-- self.RagdollParent.RagdollBoundsFresh = nil

	-- end

-- end

-- if SERVER then

	-- util.AddNetworkString("ResizedRagdoll_ClientPhysObj_GetFromSv")
	-- util.AddNetworkString("ResizedRagdoll_ClientPhysObj_SendToCl")


	-- //If we received a request for a physics mesh, then send it to the client
	-- net.Receive("ResizedRagdoll_ClientPhysObj_GetFromSv", function(_, ply)
		-- local ent = net.ReadEntity()
		-- if !IsValid(ent) then return end
		-- if !ent.RagdollParent then return end
		-- if !ent:GetPhysicsObject():IsValid() then return end

		-- net.Start( "ResizedRagdoll_ClientPhysObj_SendToCl" )
			-- net.WriteEntity(ent)

			-- //Send some other stuff to the client that it'll also need
			-- net.WriteEntity(ent.RagdollParent)
			-- net.WriteInt(ent.PhysBoneNum, 11)

			-- //Instead of networking a TON of vectors to send the entire physics mesh to the client, we can save on network stress by just sending the mins and maxs
			-- //of the mesh's bounding box. We're not actually using the clientside physobj for collisions or anything, so it doesn't need to be all that detailed.
			-- local meshmins, meshmaxs = Vector(0,0,0), Vector(0,0,0)
			-- for _, convextab in pairs (ent.RagdollParent.PhysObjMeshes[ent.PhysBoneNum]) do
				-- for _, vect in pairs (convextab) do
					-- meshmins = Vector( math.min(vect.x, meshmins.x), math.min(vect.y, meshmins.y), math.min(vect.z, meshmins.z) )
					-- meshmaxs = Vector( math.max(vect.x, meshmaxs.x), math.max(vect.y, meshmaxs.y), math.max(vect.z, meshmaxs.z) )
				-- end
			-- end
			-- net.WriteVector(meshmins * ent.RagdollParent.PhysObjScales[ent.PhysBoneNum])
			-- net.WriteVector(meshmaxs * ent.RagdollParent.PhysObjScales[ent.PhysBoneNum])

			-- net.WriteString(ent:GetPhysicsObject():GetMaterial())
		-- net.Send(ply)
	-- end)

-- else

	-- //If we received a physbones table from the server, then use it
	-- net.Receive("ResizedRagdoll_ClientPhysObj_SendToCl", function()
		-- local ent = net.ReadEntity()
		-- if !IsValid(ent) then return end
		-- if ent:GetPhysicsObject():IsValid() then return end

		-- ent.RagdollParent = net.ReadEntity()
		-- ent.PhysBoneNum = net.ReadInt(11)

		-- local meshmins = net.ReadVector()
		-- local meshmaxs = net.ReadVector()
		-- local mesh = {{
			-- meshmins, Vector( meshmins.x, meshmaxs.y, meshmins.z ), Vector( meshmins.x, meshmaxs.y, meshmaxs.z ), Vector( meshmins.x, meshmins.y, meshmaxs.z ),
			-- Vector( meshmaxs.x, meshmins.y, meshmins.z ), Vector( meshmaxs.x, meshmaxs.y, meshmins.z ), meshmaxs, Vector( meshmaxs.x, meshmins.y, meshmaxs.z ),
		-- }}

		-- ent:PhysicsInitMultiConvex(mesh)
		-- ent.ReceivedPhysObj = true

		-- local phys = ent:GetPhysicsObject()
		-- if !IsValid(phys) then return end
		-- phys:SetMaterial(net.ReadString())

		-- phys:SetPos(ent:GetPos())
		-- phys:SetAngles(ent:GetAngles())
		-- phys:EnableMotion(false)
		-- phys:Sleep() //the clientside physobj likes to break things unless it's asleep

		-- ent:SetRenderBounds( ent:GetCollisionBounds() )
	-- end)


	-- function ENT:Think()

		-- if !self.ReceivedPhysObj then
			-- //We need to generate the physics object clientside as well, so clientside traces can hit the entity
			-- net.Start( "ResizedRagdoll_ClientPhysObj_GetFromSv" )
				-- net.WriteEntity(self)
			-- net.SendToServer()
		-- end

		-- //Bandaid fix for demo recording (see prop_resizedragdoll_physparent think func) - when recording begins, the clientside physobj is lost but self.ReceivedPhysObj is still
		-- //true, so check if the physobj is gone and set self.ReceivedPhysObj to nil so we request a new one from the server.
		-- if engine.IsRecordingDemo() and self.ReceivedPhysObj and !IsValid(self:GetPhysicsObject()) then
			-- self.ReceivedPhysObj = nil
		-- end

	-- end


	-- //We don't want to draw the physobj ents, but we can't use SetNoDraw or it'll cause visual jittering when moving the ragdoll
	-- //debug: comment these out to make the SetColor bit below in PhysicsUpdate work
	-- function ENT:Draw()
	-- end
	-- function ENT:DrawTranslucent()
	-- end

-- end




-- if SERVER then

	-- function ENT:PhysicsUpdate(phys)

		-- --[[//debug: show where the physobj is and if it's held by the physgun
		-- if phys:IsValid() and phys:HasGameFlag(FVPHYSICS_PLAYER_HELD) then
			-- self:SetColor(Color(255,0,0,255))
		-- else
			-- self:SetColor(Color(0,255,0,255))
		-- end]]

		-- //If the ragdoll is being carried by the physgun or was just frozen, then run a "stretch prevention" function to make sure all the physobjs are in the right spot
		-- if phys:IsValid() and self.RagdollParent and self.RagdollParent.DoneGeneratingPhysObjs then
			-- if phys:HasGameFlag(FVPHYSICS_PLAYER_HELD) then
				-- self.ShouldCorrectPhysObj = true
			-- else
				-- if !phys:IsMotionEnabled() then
					-- if self.StopMovingOnceFrozen and self.StopMovingOnceFrozen > 0 then
						-- self.StopMovingOnceFrozen = self.StopMovingOnceFrozen - 1
						-- self.ShouldCorrectPhysObj = true
					-- else
						-- self.ShouldCorrectPhysObj = false
					-- end
				-- else
					-- self.ShouldCorrectPhysObj = false
				-- end
			-- end

			-- //One physobj should be constantly checking if we need to run the function (we can't do this in the ragdoll's think hook because it's not fast enough)
			-- if self.PhysBoneNum == 0 then
				-- for k, ent in pairs (self.RagdollParent.PhysObjEnts) do
					-- if ent.ShouldCorrectPhysObj then self.RagdollParent:CorrectPhysObjLocations() return end
				-- end
			-- end
		-- end

		-- //A physobj moved, so tell the parent to recompute the ragdoll bounds
		-- self.RagdollParent.RagdollBoundsFresh = nil

	-- end

	-- hook.Add( "OnPhysgunFreeze", "ResizedRagdoll_OnPhysObjFreeze", function(weapon, phys, ent, ply)
		-- if ent:GetClass() == "prop_resizedragdoll_physobj" then
			-- ent.StopMovingOnceFrozen = 8 //when a physobj is frozen by the physgun, let CorrectPhysObjLocations settle its location for a few iterations
		-- end				     //before becoming less strict about its location (see the code for the function) so it doesn't freeze in a bad spot
	-- end )

-- end




-- //Don't duplicate this - the parent entity recreates the physobj ents from scratch when it spawns
-- duplicator.RegisterEntityClass( "prop_resizedragdoll_physobj", function( ply, data )
-- end, "Data" )