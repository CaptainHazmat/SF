ENT.Type 			= "point"
ENT.Base 			= "base_gmodentity"
ENT.PrintName		= "Patrol Point"
ENT.Author			= "Silverlan"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
