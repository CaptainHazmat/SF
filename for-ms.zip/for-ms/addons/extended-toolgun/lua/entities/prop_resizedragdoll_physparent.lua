

-- AddCSLuaFile()

-- ENT.Base 			= "base_gmodentity"
-- ENT.PrintName			= "Resized Ragdoll"

-- ENT.Spawnable			= false
-- ENT.AdminSpawnable		= false

-- ENT.AutomaticFrameAdvance	= true
-- ENT.RenderGroup			= false //let the engine set the rendergroup by itself

-- ENT.ClassOverride		= "prop_resizedragdoll_physparent"




-- //Prints debug messages into console if developer mode is enabled; used to try to diagnose function detour issues reported by other users that can't be reproduced, remove once issues are fixed
-- local function RagdollResizerDebugMsg(str, str2, ...)
	-- local developer = GetConVar("developer")
	-- if developer and developer:GetInt() > 0 then
		-- local prefix = ""
		-- if SERVER then 
			-- prefix = " (SERVER)"
		-- elseif CLIENT then
			-- prefix = " (CLIENT)"
		-- end
		-- if istable(str2) then
			-- MsgN("RAGDOLL RESIZER", prefix, ": ", str)
			-- PrintTable(str2)
		-- elseif str2 == nil then
			-- MsgN("RAGDOLL RESIZER", prefix, ": ", str)
		-- else
			-- MsgN("RAGDOLL RESIZER", prefix, ": ", str, str2, ...)
		-- end
	-- end
-- end
-- RagdollResizerDebugMsg("Debug messages on")




-- function ENT:Initialize()

	-- if SERVER then

		-- if !self.PhysObjScales then MsgN("ERROR: Resized ragdoll " .. self:GetModel() .. " doesn't have a PhysObjScales table! Something went wrong!") self:Remove() return end
		-- if !self.PhysObjMeshes then MsgN("ERROR: Resized ragdoll " .. self:GetModel() .. " doesn't have a PhysObjMeshes table! Something went wrong!") self:Remove() return end

		-- //Have a dummy ent use FollowBone to expose all of the entity's bones. If we don't do this, a whole bunch of bones can return as invalid clientside, 
		-- //as well as return the wrong locations serverside.
		-- local lol = ents.Create("base_point")
		-- lol:SetPos(self:GetPos())
		-- lol:SetAngles(self:GetAngles())
		-- lol:FollowBone(self,0)
		-- lol:Spawn()
		-- lol:Remove() //We don't need the ent to stick around. All we needed was for it to use FollowBone once.

		-- self:SetAngles(Angle(0,0,0))
		-- local sequence = self:LookupSequence("ragdoll")
		-- if sequence != -1 then self:SetSequence(sequence) self:ResetSequence(sequence) end


		-- //Get the model's info table and process it - we'll need it to set up the physobjs
		-- local modelinforaw = util.GetModelInfo(self:GetModel())
		-- if !modelinforaw or !modelinforaw.KeyValues then
			-- if !util.IsValidModel(self:GetModel()) then
				-- MsgN("RAGDOLL RESIZER: Removed resized ragdoll ", self:GetModel(), " because we can't get its model info due to an invalid model. (dupe/save using a model that's not installed?)")
			-- else
				-- MsgN("RAGDOLL RESIZER: Removed resized ragdoll ", self:GetModel(), " because we can't get its model info for an unknown reason.")
			-- end
			-- self:Remove()
			-- return 
		-- end
		-- self.ModelInfo = {}
		-- for _, tab in pairs (util.KeyValuesToTablePreserveOrder(modelinforaw.KeyValues)) do
			-- --[[MsgN(tab.Key)
			-- for _, tab2 in pairs (tab.Value) do
				-- MsgN( tab2.Key .. " = " .. tab2.Value )
			-- end
			-- MsgN("")]]

			-- if tab.Key == "solid" then
				-- self.ModelInfo.Solids = self.ModelInfo.Solids or {}

				-- local tabprocessed = {}
				-- for _, tab2 in pairs (tab.Value) do
					-- tabprocessed[tab2.Key] = tab2.Value
				-- end

				-- self.ModelInfo.Solids[tabprocessed["index"]] = tabprocessed
			-- end

			-- if tab.Key == "ragdollconstraint" then
				-- self.ModelInfo.Constraints = self.ModelInfo.Constraints or {}

				-- local tabprocessed = {}
				-- for _, tab2 in pairs (tab.Value) do
					-- tabprocessed[tab2.Key] = tab2.Value
				-- end

				-- self.ModelInfo.Constraints[tabprocessed["child"]] = tabprocessed
			-- end

			-- if tab.Key == "collisionrules" then
				-- self.ModelInfo.CollisionPairs = self.ModelInfo.CollisionPairs or {}

				-- for _, tab2 in pairs (tab.Value) do
					-- if tab2.Key == "collisionpair" then
						-- local pair = string.Explode( ",", tab2.Value, false)
						-- table.insert(self.ModelInfo.CollisionPairs, pair)
					-- elseif tab2.Key == "selfcollisions" then
						-- self.ModelInfo.SelfCollisions = tab2.Value
					-- end
				-- end
			-- end
		-- end
		-- //PrintTable(self.ModelInfo)


		-- //self:TranslateBoneToPhysBone() just doesn't work at all on some models, so we can't rely on it - make a table to use instead
		-- self.PhysObjPhysBoneIDs = {}
		-- for i = 0, table.Count(self.ModelInfo.Solids) - 1 do

			-- self.PhysObjPhysBoneIDs[self.ModelInfo.Solids[i]["name"]] = i

		-- end

		-- //Generate physbone offsets - use the modelinfo table to determine which physobjs are parented to which, and then get their offset from their parent.
		-- //We need this because we need to multiply the position offset by the parent physbone's scale.
		-- for i = 0, table.Count(self.ModelInfo.Solids) - 1 do

			-- if self.ModelInfo.Solids[i]["parent"] then
				-- //Physobj has a parent physobj, so get its offset from that
				-- local bonepos = self:GetBoneMatrix( self:TranslatePhysBoneToBone(i) ):GetTranslation()
				-- local parboneid = self:LookupBone(self.ModelInfo.Solids[i]["parent"])
				-- local parbonepos, parboneang = self:GetBoneMatrix( parboneid ):GetTranslation(), self:GetBoneMatrix( parboneid ):GetAngles()

				-- local offsetpos, _ = WorldToLocal(bonepos, Angle(0,0,0), parbonepos, parboneang)
				-- self.ModelInfo.Solids[i]["offsetpos"] = offsetpos * self.PhysObjScales[ self.PhysObjPhysBoneIDs[self.ModelInfo.Solids[i]["parent"]] ]
			-- else
				-- //Physobj doesn't have a parent physobj, so get its offset from the model origin
				-- local bonepos = self:GetBoneMatrix( self:TranslatePhysBoneToBone(i) ):GetTranslation()

				-- local offsetpos, _ = WorldToLocal(bonepos, Angle(0,0,0), self:GetPos(), self:GetAngles())
				-- self.ModelInfo.Solids[i]["offsetpos"] = offsetpos
			-- end

		-- end

		-- //Create the physics objects
		-- self.PhysObjs = {}
		-- self.PhysObjEnts = {}
		-- local PhysObjErrors = {}
		-- for i = 0, table.Count(self.ModelInfo.Solids) - 1 do

			-- local matr = self:GetBoneMatrix( self:TranslatePhysBoneToBone(i) )
			-- if matr then
				-- local physent = ents.Create("prop_resizedragdoll_physobj")

				-- if self.ModelInfo.Solids[i]["parent"] and self.ModelInfo.Solids[i]["parent"] != self.ModelInfo.Solids[i]["name"] then
					-- //Physobj has a parent physobj, so use its offset from that (TODO: What if a model is set up so that the parent physobj is created LATER than its
					-- //child for some reason? That would break everything since we wouldn't be able to get the parent's position!)
					-- local parphysobjid = self.PhysObjPhysBoneIDs[self.ModelInfo.Solids[i]["parent"]]
					-- local parphysent = self.PhysObjEnts[parphysobjid]
					-- if !IsValid(parphysent) then
						-- PhysObjErrors[i] = i .. ": " .. self.ModelInfo.Solids[i]["name"] .. " couldn't be created because its parent (" .. self.ModelInfo.Solids[i]["parent"]  .. ") doesn't exist/failed to generate."
						-- continue
					-- end
					-- local ourpos, _ = LocalToWorld(self.ModelInfo.Solids[i]["offsetpos"], Angle(0,0,0), parphysent:GetPos(), parphysent:GetAngles())
					-- physent:SetPos(ourpos)

					-- //Store this stuff in the physent so it can use it itself
					-- physent.PhysParent = parphysent
					-- physent.PhysParentOffsetPos = self.ModelInfo.Solids[i]["offsetpos"]
				-- else
					-- //Physobj doesn't have a parent physobj, so use its offset from the model origin
					-- local ourpos, _ = LocalToWorld(self.ModelInfo.Solids[i]["offsetpos"], Angle(0,0,0), self:GetPos(), self:GetAngles())
					-- physent:SetPos(ourpos)
				-- end

				-- physent:SetAngles(matr:GetAngles())
				-- physent:SetModel("models/hunter/plates/plate.mdl")
				-- physent:DrawShadow(false)

				-- physent.RagdollParent = self
				-- physent.PhysBoneNum = i
				-- physent:Spawn()

				-- //multiply each of the vectors inside the mesh table by our scale
				-- local scaledmesh = {}
				-- for convexnum, convextab in pairs (self.PhysObjMeshes[i]) do
					-- scaledmesh[convexnum] = scaledmesh[convexnum] or {}
					-- for _, v in pairs (convextab) do
						-- table.insert(scaledmesh[convexnum], v * self.PhysObjScales[i] )
					-- end
				-- end
				-- physent:PhysicsInitMultiConvex(scaledmesh)
				-- --[[if !physent:GetPhysicsObject():IsValid() then  //the physobj can fail to generate if the mesh is really small, so if that happens use a backup mesh
					-- physent:PhysicsInitMultiConvex({{
						-- Vector(0.75, 0.75, 0.75), Vector(-0.75, 0.75, 0.75),
						-- Vector(0.75, -0.75, 0.75), Vector(-0.75, -0.75, 0.75),
						-- Vector(0.75, 0.75, -0.75), Vector(-0.75, 0.75, -0.75),
						-- Vector(0.75, -0.75, -0.75), Vector(-0.75, -0.75, -0.75),
						-- //Vector(1, 1, 1), Vector(-1, 1, 1),
						-- //Vector(1, -1, 1), Vector(-1, -1, 1),
						-- //Vector(1, 1, -1), Vector(-1, 1, -1),
						-- //Vector(1, -1, -1), Vector(-1, -1, -1),
					-- }})
					-- physent:SetCollisionGroup(COLLISION_GROUP_NONE)
				-- end]]
				-- physent:EnableCustomCollisions(true)
				-- physent:SetMoveType(MOVETYPE_VPHYSICS)
				-- physent:SetSolid(SOLID_VPHYSICS)
				-- local physobj = physent:GetPhysicsObject()
				-- if !physobj:IsValid() then
					-- //the backup mesh idea doesn't work very well, presumably because the mesh's center of gravity isn't in the right place, so just remove the entity
					-- PhysObjErrors[i] = i .. ": " .. self.ModelInfo.Solids[i]["name"] .. " failed to generate. This is usually because its collision mesh was too small or too thin for the engine to handle - you might have to increase its size a bit, or make the differences between the X, Y and Z scales less extreme."
					-- physent:Remove()
					-- continue
				-- end  

				-- physobj:SetMass( self.ModelInfo.Solids[i]["mass"] * self.PhysObjScales[i].x * self.PhysObjScales[i].y * self.PhysObjScales[i].z )
				-- physobj:SetMaterial( self.ModelInfo.Solids[i]["surfaceprop"] )				
				-- physobj:SetDamping( self.ModelInfo.Solids[i]["damping"], self.ModelInfo.Solids[i]["rotdamping"] )
				-- local inertia = self.ModelInfo.Solids[i]["inertia"]
				-- if inertia > 0 then physobj:SetInertia( physobj:GetInertia() * Vector(inertia,inertia,inertia) ) end

				-- physobj:Wake()

				-- self:DeleteOnRemove(physent)
				-- physent:DeleteOnRemove(self)
				-- self.PhysObjs[i] = physobj
				-- self.PhysObjEnts[i] = physent
			-- end

		-- end
		-- //Error handling for physobj creation
		-- if self.ErrorRecipient and table.Count(PhysObjErrors) > 0 then
			-- //Print detailed errors in the console explaining which physobjs failed to generate and why
			-- MsgN("RAGDOLL RESIZER:")
			-- MsgN(tostring(self) .. " (" .. string.GetFileFromFilename(self:GetModel()) .. ") :")
			-- for k, v in pairs (PhysObjErrors) do
				-- MsgN(v)
			-- end
			-- if table.Count(self.PhysObjEnts) == 0 then
				-- MsgN(tostring(self) .. " (" .. string.GetFileFromFilename(self:GetModel()) .. "didn't generate any physobjs, removing...")
				-- PhysObjErrors = {} //use an error count of 0 as a special case when networking (see below) to show a different message when no physobjs generate at all
			-- end
			-- MsgN("")

			-- //Tell the client that spawned the ragdoll to show a notification on the HUD letting the player about the error and directing them to the console
			-- net.Start( "ResizedRagdoll_FailedToGenerate_SendToCl" )
				-- net.WriteInt(table.Count(PhysObjErrors), 11)
			-- net.Send(self.ErrorRecipient)

			-- //If we couldn't generate s single physobj, then remove the entity
			-- if table.Count(self.PhysObjEnts) == 0 then
				-- self:Remove() 
				-- return 
			-- end
		-- end
		-- self.ErrorRecipient = nil //don't send the notification again if the player dupes/saves the ragdoll, once is enough


		-- //Apply ragdoll constraints
		-- if self.ModelInfo.Constraints then

			-- self.ConstraintSystem = ents.Create("phys_constraintsystem")
			-- self.ConstraintSystem:SetKeyValue( "additionaliterations", GetConVarNumber( "gmod_physiterations" ) )
			-- self.ConstraintSystem:SetName("constraintsystem_" .. self:EntIndex())
			-- self.ConstraintSystem:Spawn()
			-- self.ConstraintSystem:Activate()
			-- self:DeleteOnRemove(self.ConstraintSystem)
			-- SetPhysConstraintSystem(self.ConstraintSystem)

			-- for _, constrainttab in pairs (self.ModelInfo.Constraints) do

				-- local parentent = self.PhysObjEnts[ constrainttab["parent"] ]
				-- local childent = self.PhysObjEnts[ constrainttab["child"] ]
				-- local parentphys = self.PhysObjs[ constrainttab["parent"] ]
				-- local childphys = self.PhysObjs[ constrainttab["child"] ]
				-- if !IsValid(parentent) or !IsValid(childent) or !parentphys:IsValid() or !childphys:IsValid() then continue end
	
				-- local Constraint = ents.Create("phys_ragdollconstraint")
				-- Constraint:SetPos(childphys:GetPos())
				-- Constraint:SetAngles(parentphys:GetAngles())

				-- local mins = Vector( constrainttab["xmin"], constrainttab["ymin"], constrainttab["zmin"] )
				-- local maxs = Vector( constrainttab["xmax"], constrainttab["ymax"], constrainttab["zmax"] )
				-- local _, offsetang = WorldToLocal(childent:GetPos(), childent:GetAngles(), parentent:GetPos(), parentent:GetAngles())
				-- mins:Rotate(offsetang)
				-- maxs:Rotate(offsetang)
				-- Constraint:SetKeyValue( "xmin", math.min(mins.x,maxs.x) )
				-- Constraint:SetKeyValue( "xmax", math.max(mins.x,maxs.x) )
				-- Constraint:SetKeyValue( "ymin", math.min(mins.y,maxs.y) )
				-- Constraint:SetKeyValue( "ymax", math.max(mins.y,maxs.y) )
				-- Constraint:SetKeyValue( "zmin", math.min(mins.z,maxs.z) )
				-- Constraint:SetKeyValue( "zmax", math.max(mins.z,maxs.z) )

				-- //TODO: Find a better way to handle friction; these values don't rotate well and averaging them isn't much better. 
				-- //For now, I guess we'll just settle for ultra-floppy frictionless ragdolls.
				-- --[[local friction = Vector( constrainttab["xfriction"], constrainttab["yfriction"], constrainttab["zfriction"] )
				-- friction:Rotate(offsetang)
				-- Constraint:SetKeyValue( "xfriction", math.Clamp(friction.x, 0, friction.x) )
				-- Constraint:SetKeyValue( "yfriction", math.Clamp(friction.y, 0, friction.y) )
				-- Constraint:SetKeyValue( "zfriction", math.Clamp(friction.z, 0, friction.z) )]]
				-- --[[local avgfriction = ( constrainttab["xfriction"] + constrainttab["yfriction"] + constrainttab["zfriction"] ) / 3
				-- Constraint:SetKeyValue( "xfriction", avgfriction )
				-- Constraint:SetKeyValue( "yfriction", avgfriction )
				-- Constraint:SetKeyValue( "zfriction", avgfriction )]]

				-- Constraint:SetKeyValue( "spawnflags", 1 )  //nocollide
				-- Constraint:SetKeyValue( "constraintsystem", "constraintsystem_" .. self:EntIndex() ) 
				-- Constraint:SetPhysConstraintObjects( parentphys, childphys )
				-- Constraint:Spawn()
				-- Constraint:Activate()
				-- self:DeleteOnRemove(Constraint)

			-- end

			-- SetPhysConstraintSystem(NULL)
		-- end


		-- //Apply collision rules by adding logic_collision_pairs for all physobj pairs we don't want to collide
		-- local RagdollCollisions = {}
		-- local function RagdollCollisionPair(phys1,phys2)
			-- if !IsValid(phys1) or !IsValid(phys2) or phys1 == phys2 then return end
			-- for _, tab in pairs (RagdollCollisions) do
				-- //If we've already made a collision pair between these two physobjs then stop here
				-- if (tab.Phys1 == phys1 and tab.Phys2 == phys2) or (tab.Phys2 == phys1 and tab.Phys1 == phys2) then return end
			-- end

			-- local Constraint = ents.Create("logic_collision_pair")
			-- Constraint:SetKeyValue( "startdisabled", 1 )
			-- Constraint:SetPhysConstraintObjects( phys1, phys2 )
			-- Constraint:Spawn()
			-- Constraint:Activate()
			-- self:DeleteOnRemove(Constraint)
			-- Constraint:Input( "DisableCollisions", nil, nil, nil )

			-- table.insert( RagdollCollisions, {["Phys1"] = phys1, ["Phys2"] = phys2} )
		-- end

		-- if self.ModelInfo.SelfCollisions and self.ModelInfo.SelfCollisions == 0 then
			-- //If selfcollisions == 0, then none of the physobjs should collide with each other
			-- for physnum1 = 0, table.Count(self.ModelInfo.Solids) - 1 do
				-- for physnum2 = 0, table.Count(self.ModelInfo.Solids) - 1 do
					-- RagdollCollisionPair(self.PhysObjs[physnum1], self.PhysObjs[physnum2])
				-- end
			-- end
		-- elseif self.ModelInfo.CollisionPairs then
			-- //If collisionpairs are present, then only those pairs should collide with each other
			-- for physnum1 = 0, table.Count(self.ModelInfo.Solids) - 1 do
				-- for physnum2 = 0, table.Count(self.ModelInfo.Solids) - 1 do
					-- local shouldcollide = false
					-- for _, colpair in pairs (self.ModelInfo.CollisionPairs) do
						-- if (colpair[1] == physnum1 and colpair[2] == physnum2) or (colpair[2] == physnum1 and colpair[1] == physnum2) then
							-- shouldcollide = true
						-- end
					-- end
					-- if !shouldcollide then RagdollCollisionPair(self.PhysObjs[physnum1], self.PhysObjs[physnum2]) end
				-- end
			-- end
		-- end


		-- //Run the PostInitializeFunction to move the physobjs into place
		-- if self.PostInitializeFunction then self.PostInitializeFunction() end
		-- self.DoneGeneratingPhysObjs = true
		-- return

	-- end


	-- self:SetLOD(0)
	-- self:SetupBones()
	-- self:InvalidateBoneCache()
	-- //self:DestroyShadow()

	-- self.LastBuildBonePositionsTime = 0
	-- self.SavedBoneMatrices = {}
	-- self:AddCallback("BuildBonePositions", self.BuildBonePositions)

-- end

-- if CLIENT then

	-- function ENT:BuildBonePositions()

		-- if !self or self == NULL then return end
		-- if !self.PhysBones then return end

		-- //This function is expensive, so make sure we aren't running it more often than we need to
		-- if self.LastBuildBonePositionsTime == CurTime() then
			-- for i = 0, self:GetBoneCount() - 1 do
				-- if self.SavedBoneMatrices[i] and self:GetBoneName(i) != "__INVALIDBONE__" then
					-- self:SetBoneMatrix(i, self.SavedBoneMatrices[i])
				-- end
			-- end
			-- return
		-- else
			-- self.LastBuildBonePositionsTime = CurTime()
		-- end


		-- //Create a table of bone offsets for bones to use if they're not following a physobj
		-- if !self.BoneOffsets then
			-- //Grab the bone matrices from a clientside model instead - if we use ourselves, any bone manips we already have will be applied to the 
			-- //matrices, making the altered bones the new default (and then the manips will be applied again on top of them, basically "doubling" the manips)
			-- if !self.csmodel and self.NetworkedModelName then
				-- self.csmodel = ClientsideModel(self.NetworkedModelName,RENDERGROUP_TRANSLUCENT)
				-- self.csmodel:SetPos(self:GetPos())
				-- self.csmodel:SetAngles(self:GetAngles())
				-- self.csmodel:SetMaterial("null")  //invisible texture, so players don't see the csmodel for a split second while we're generating the table
				-- self.csmodel:SetLOD(0)
			-- end
			-- self.csmodel:DrawModel()
			-- self.csmodel:SetupBones()
			-- self.csmodel:InvalidateBoneCache()
			-- if self.csmodel and self.csmodel:GetBoneMatrix(0) == nil then return end  //the csmodel needs a frame or so to start returning the matrices

			-- local boneoffsets = {}
			-- for i = 0, self:GetBoneCount() - 1 do
				-- local newentry = {
					-- posoffset = Vector(0,0,0),
					-- angoffset = Angle(0,0,0),
				-- }
				-- local parentboneid = self.csmodel:GetBoneParent(i)
				-- if parentboneid and parentboneid != -1 then
					-- local parentmatr = self.csmodel:GetBoneMatrix(parentboneid)
					-- local ourmatr = self.csmodel:GetBoneMatrix(i)
					-- if ourmatr == nil then return end
					-- newentry["posoffset"], newentry["angoffset"] = WorldToLocal(ourmatr:GetTranslation(), ourmatr:GetAngles(), parentmatr:GetTranslation(), parentmatr:GetAngles())
				-- elseif i == 0 then
					-- local ourmatr = self.csmodel:GetBoneMatrix(i)
					-- if ourmatr == nil then return end
					-- newentry["posoffset"], newentry["angoffset"] = WorldToLocal(ourmatr:GetTranslation(), ourmatr:GetAngles(), self:GetPos(), self:GetAngles())
				-- end
				-- table.insert(boneoffsets, i, newentry)
			-- end
			-- self.BoneOffsets = boneoffsets

			-- local physboneoffsets = {}
			-- for i = 0, self:GetBoneCount() - 1 do
				-- if self.PhysBones[i] and self.PhysBones[i].parentid != -1 then
					-- local parentmatr = self.csmodel:GetBoneMatrix(self.PhysBones[i].parentid)
					-- local ourmatr = self.csmodel:GetBoneMatrix(i)
					-- if ourmatr != nil then
						-- //we don't need an angle offset for these ones
						-- local pos = WorldToLocal(ourmatr:GetTranslation(), ourmatr:GetAngles(), parentmatr:GetTranslation(), parentmatr:GetAngles())
						-- table.insert(physboneoffsets, i, pos)
					-- end
				-- end
			-- end
			-- self.PhysBoneOffsets = physboneoffsets

			-- //We'll remove the clientside model in our Think hook, because doing it here can cause a crash (multiple BuildBonePositions calls trying to remove it simultaneously, maybe?)
			-- self.csmodeltoremove = self.csmodel
			-- self.csmodel = nil
		-- end


		-- for i = 0, self:GetBoneCount() - 1 do

			-- local matr = nil

			-- local parentmatr = nil
			-- local parentboneid = self:GetBoneParent(i)
			-- if parentboneid and parentboneid != -1 then
				-- parentmatr = self:GetBoneMatrix(parentboneid)
			-- else
				-- parentmatr = Matrix()
				-- parentmatr:SetTranslation(self:GetPos())
				-- parentmatr:SetAngles(self:GetAngles())
			-- end
			-- if parentmatr then
				-- parentmatr:Translate(self.BoneOffsets[i]["posoffset"])
				-- parentmatr:Translate(self:GetManipulateBonePosition(i))
				-- parentmatr:Rotate(self.BoneOffsets[i]["angoffset"])
				-- parentmatr:Rotate(self:GetManipulateBoneAngles(i))
			-- end

			-- if self.PhysBones[i] and IsValid(self.PhysBones[i].entity) then
				-- //Follow the physics object entity, but use the position offset from our parent physobj if we have one so that the ragdoll never looks "stretched"
				-- matr = Matrix()
				-- local physparentmatr = nil
				-- if self.PhysBoneOffsets[i] then
					-- physparentmatr = self:GetBoneMatrix(self.PhysBones[i].parentid)
				-- end
				-- if physparentmatr then
					-- physparentmatr:Translate(self.PhysBoneOffsets[i])
					-- matr:SetTranslation(physparentmatr:GetTranslation())
				-- else
					-- matr:SetTranslation(self.PhysBones[i].entity:GetPos())
				-- end
				-- matr:SetAngles(self.PhysBones[i].entity:GetAngles())
				-- matr:Scale( self.PhysBones[i].scalevec )
			-- else
				-- //Follow our parent bone
				-- if parentmatr then matr = parentmatr end
			-- end


			-- if matr then
				-- if self:GetBoneName(i) != "__INVALIDBONE__" then
					-- self:SetBoneMatrix(i,matr)
					-- self.SavedBoneMatrices[i] = matr
				-- end

				-- //Note: Jigglebones currently don't work because their procedurally generated matrix is replaced with the one we're giving them here.
				-- //We can detect jigglebones and do things to them specifically with self:BoneHasFlag(i,BONE_ALWAYS_PROCEDURAL), but there doesn't seem to be an easy way
				-- //to keep everything working (bone parenting, etc.) while still allowing the bones to jiggle.
			-- end

		-- end

	-- end

-- end




-- //Networking crap - 
-- //Step 1: If we're the client and we don't have a physbones table, request it from the server.
-- //Step 2: If we're the server and we receive a request, send a physbones table.
-- //Step 3: If we're the client and we receive a physbones table, use it.

-- //ResizedRagdoll_PhysBonesTable_GetFromSv structure:
-- //	Entity: Entity that needs a PhysBones table

-- //ResizedRagdoll_PhysBonesTable_SendToCl structure:
-- //	Entity: Entity that needs a PhysBones table
-- //
-- //	String: Serverside model name
-- //
-- //	Int(11): Number of table entries
-- //	FOR EACH ENTRY:
-- //		Int(11): Key for this entry (bone index)
-- //
-- //		Entity: Physobj entity
-- //		Vector: Physobj scale
-- //		Int(11): Parent physobj's bone index

-- //ResizedRagdoll_FailedToGenerate_SendToCl structure:
-- //	Int(11): Number of physobjs that failed to generate (or 0 if none generated)

-- if SERVER then 

	-- util.AddNetworkString("ResizedRagdoll_PhysBonesTable_GetFromSv")
	-- util.AddNetworkString("ResizedRagdoll_PhysBonesTable_SendToCl")
	-- util.AddNetworkString("ResizedRagdoll_FailedToGenerate_SendToCl")


	-- //If we received a request for a physbones table, then send it to the client
	-- net.Receive("ResizedRagdoll_PhysBonesTable_GetFromSv", function(_, ply)
		-- local ent = net.ReadEntity()
		-- if !IsValid(ent) then return end
		-- if !ent.DoneGeneratingPhysObjs then return end

		-- net.Start( "ResizedRagdoll_PhysBonesTable_SendToCl" )
			-- net.WriteEntity(ent)

			-- //Also use this opportunity to send the client the serverside name of the ent's model - an obscure bug on badly-made models can cause ent:GetModel() to return 
			-- //the wrong model name clientside, breaking the BuildBonePositions function, so we need to send it the correct name just in case
			-- net.WriteString(ent:GetModel())

			-- net.WriteInt(table.Count(ent.PhysObjEnts), 11)
			-- for k, ent2 in pairs (ent.PhysObjEnts) do
				-- net.WriteInt(ent:TranslatePhysBoneToBone(k), 11)

				-- net.WriteEntity(ent2)
				-- net.WriteVector(ent.PhysObjScales[k])

				-- local parentname = ent.ModelInfo.Solids[k]["parent"]
				-- local parentid = nil
				-- if parentname and parentname != ent.ModelInfo.Solids[k]["name"] then parentid = ent:LookupBone(parentname) end
				-- net.WriteInt(parentid or -1, 11)
			-- end
		-- net.Send(ply)
	-- end)

-- end

-- if CLIENT then

	-- //If we received a physbones table from the server, then use it
	-- net.Receive("ResizedRagdoll_PhysBonesTable_SendToCl", function()
		-- local ent = net.ReadEntity()
		-- if !IsValid(ent) then return end
		-- if ent.PhysBones then return end

		-- //Also store the serverside model name it sent us
		-- ent.NetworkedModelName = net.ReadString()

		-- //Store the physbones table - this table has a different format than anything used serverside, for ease of use with the BuildBonePositions callback
		-- local count = net.ReadInt(11)
		-- local tab = {}
		-- for i = 1, count do
			-- local key = net.ReadInt(11)

			-- tab[key] = {
				-- ["entity"] = net.ReadEntity(),
				-- ["scalevec"] = net.ReadVector(),
				-- ["parentid"] = net.ReadInt(11),
			-- }
		-- end
		-- ent.PhysBones = tab
	-- end)


	-- //If we received an error message from the server telling us that physobjs failed to generate, then show a notification on the HUD
	-- net.Receive("ResizedRagdoll_FailedToGenerate_SendToCl", function()
		-- local message = ""
		-- local count = net.ReadInt(11)
		-- if count == 0 then
			-- message = "All physics objects failed to generate - check console for details"
		-- elseif count == 1 then
			-- message = "1 physics object failed to generate - check console for details"
		-- else
			-- message = count .. " physics objects failed to generate - check console for details"
		-- end

		-- GAMEMODE:AddNotify(message, NOTIFY_ERROR, 5)
		-- surface.PlaySound("buttons/button11.wav")
	-- end)


	-- function ENT:Think()

		-- //Bandaid fix for demo recording and playback - oh boy, this one's a doozy. This only applies to resized ragdolls spawned BEFORE recording a demo - they don't seem to have
		-- //any problems if spawned during a demo instead.
		-- //
		-- //This issue is two-pronged - first off, when demo recording begins, some clientside information is lost (why?). The prop_resizedragdoll_physparent loses its LOD and callback
		-- //set in Initialize, so we need to set both of those again, and all the prop_resizedragdoll_physobjs lose their clientside physics objects, so we need to recreate them in 
		-- //that entity's Think function.
		-- //These, or at least the callback, don't seem to be lost until a few frames into recording, so we have to manually check for them instead of engine.IsRecordingDemo() alone.
		-- //
		-- //Second, when the demo is played back, any clientside values set on the entity BEFORE the recording was started don't seem to exist, and serverside lua doesn't run at all - 
		-- //any changes made to clientside values by server activity like net messages are part of the demo recording, not done by serverside lua. This has a lot of bad implications
		-- //for addons not made with this behavior in mind, but here, it means that self.PhysBones wasn't recorded in the demo because it was set before recording began. We set it
		-- //back to nil here while we're recording so that the server sends us a new one, which WILL be recorded in the demo.
		-- if engine.IsRecordingDemo() and #self:GetCallbacks("BuildBonePositions") == 0 then
			-- self:SetLOD(0)
			-- self:AddCallback("BuildBonePositions", self.BuildBonePositions)
			-- self.PhysBones = nil
		-- end

		-- //If we don't have a physbones table then request it from the server
		-- if !self.PhysBones then
			-- net.Start( "ResizedRagdoll_PhysBonesTable_GetFromSv" )
				-- net.WriteEntity(self)
			-- net.SendToServer()

			-- self:NextThink(CurTime())
			-- return
		-- end

		-- if !self.RagdollBoundsFresh then self:GenerateRagdollBounds() end

		-- //Set the render bounds
		-- self:SetRenderBounds(self.RagdollBoundsMin, self.RagdollBoundsMax)
		-- self:MarkShadowAsDirty()

		-- //We can't remove the clientside model inside the BuildBonePositions callback, or else it'll cause a crash for some reason - do it here instead
		-- if self.csmodeltoremove then
			-- self.csmodeltoremove:Remove()
			-- self.csmodeltoremove = nil
		-- end

	-- end




	-- local ResizedRagdoll_IsSkyboxDrawing = false

	-- hook.Add("PreDrawSkyBox", "ResizedRagdoll_IsSkyboxDrawing_Pre", function()
		-- ResizedRagdoll_IsSkyboxDrawing = true
	-- end)

	-- hook.Add("PostDrawSkyBox", "ResizedRagdoll_IsSkyboxDrawing_Post", function()
		-- ResizedRagdoll_IsSkyboxDrawing = false
	-- end)

	-- function ENT:Draw()

		-- //Don't draw in the 3D skybox if our renderbounds are clipping into it but we're not actually in there
		-- //(common problem for ents with big renderbounds on gm_flatgrass, where the 3D skybox area is right under the floor)
		-- if ResizedRagdoll_IsSkyboxDrawing and !self:GetNWBool("IsInSkybox") then return end
		-- //TODO: Fix opposite condition where ent renders in the world from inside the 3D skybox area (i.e. gm_construct) - we can't just do the opposite of this because
		-- //we still want the ent to render in the world if the player is also in the 3D skybox area with them, but we can't detect if the player is in that area clisntside

		-- if self.PhysBones then
			-- self:DrawModel()
		-- end

	-- end
	
	-- function ENT:DrawTranslucent()

		-- self:Draw()

	-- end

-- end

-- function ENT:GenerateRagdollBounds()

	-- if !(self.PhysObjEnts or self.PhysBones) then return end

	-- local pos = self:GetPos()
	-- local mins, maxs = pos, pos
	-- if !self.PhysObjEnts and self.PhysBones then  //the table structure's a bit different on the server and on the client, so just use whichever one we've got
		-- for _, v in pairs (self.PhysBones) do
			-- if IsValid(v.entity) and IsValid(v.entity:GetPhysicsObject()) then
				-- local phys = v.entity:GetPhysicsObject()

				-- local physpos, physang = phys:GetPos(), phys:GetAngles()
				-- local pmins, pmaxs = phys:GetAABB()
				-- local vects = {
					-- pmins, Vector(pmaxs.x, pmins.y, pmins.z),
					-- Vector(pmins.x, pmaxs.y, pmins.z), Vector(pmaxs.x, pmaxs.y, pmins.z),
					-- Vector(pmins.x, pmins.y, pmaxs.z), Vector(pmaxs.x, pmins.y, pmaxs.z),
					-- Vector(pmins.x, pmaxs.y, pmaxs.z), pmaxs,
				-- }
				-- for i = 1, #vects do
					-- local wspos = LocalToWorld(vects[i], Angle(0,0,0), physpos, physang)
					-- vects[i] = wspos
				-- end
				-- mins = Vector( math.min(vects[1].x, vects[2].x, vects[3].x, vects[4].x, 
						-- vects[5].x, vects[6].x, vects[7].x, vects[8].x, mins.x),
						-- math.min(vects[1].y, vects[2].y, vects[3].y, vects[4].y, 
						-- vects[5].y, vects[6].y, vects[7].y, vects[8].y, mins.y),
						-- math.min(vects[1].z, vects[2].z, vects[3].z, vects[4].z, 
						-- vects[5].z, vects[6].z, vects[7].z, vects[8].z, mins.z) )
				-- maxs = Vector( math.max(vects[1].x, vects[2].x, vects[3].x, vects[4].x, 
						-- vects[5].x, vects[6].x, vects[7].x, vects[8].x, maxs.x),
						-- math.max(vects[1].y, vects[2].y, vects[3].y, vects[4].y, 
						-- vects[5].y, vects[6].y, vects[7].y, vects[8].y, maxs.y),
						-- math.max(vects[1].z, vects[2].z, vects[3].z, vects[4].z, 
						-- vects[5].z, vects[6].z, vects[7].z, vects[8].z, maxs.z) )
			-- end
		-- end
	-- else
		-- for _, phys in pairs (self.PhysObjs) do
			-- if IsValid(phys) then
				-- local physpos, physang = phys:GetPos(), phys:GetAngles()
				-- local pmins, pmaxs = phys:GetAABB()
				-- local vects = {
					-- pmins, Vector(pmaxs.x, pmins.y, pmins.z),
					-- Vector(pmins.x, pmaxs.y, pmins.z), Vector(pmaxs.x, pmaxs.y, pmins.z),
					-- Vector(pmins.x, pmins.y, pmaxs.z), Vector(pmaxs.x, pmins.y, pmaxs.z),
					-- Vector(pmins.x, pmaxs.y, pmaxs.z), pmaxs,
				-- }
				-- for i = 1, #vects do
					-- local wspos = LocalToWorld(vects[i], Angle(0,0,0), physpos, physang)
					-- vects[i] = wspos
				-- end
				-- mins = Vector( math.min(vects[1].x, vects[2].x, vects[3].x, vects[4].x, 
						-- vects[5].x, vects[6].x, vects[7].x, vects[8].x, mins.x),
						-- math.min(vects[1].y, vects[2].y, vects[3].y, vects[4].y, 
						-- vects[5].y, vects[6].y, vects[7].y, vects[8].y, mins.y),
						-- math.min(vects[1].z, vects[2].z, vects[3].z, vects[4].z, 
						-- vects[5].z, vects[6].z, vects[7].z, vects[8].z, mins.z) )
				-- maxs = Vector( math.max(vects[1].x, vects[2].x, vects[3].x, vects[4].x, 
						-- vects[5].x, vects[6].x, vects[7].x, vects[8].x, maxs.x),
						-- math.max(vects[1].y, vects[2].y, vects[3].y, vects[4].y, 
						-- vects[5].y, vects[6].y, vects[7].y, vects[8].y, maxs.y),
						-- math.max(vects[1].z, vects[2].z, vects[3].z, vects[4].z, 
						-- vects[5].z, vects[6].z, vects[7].z, vects[8].z, maxs.z) )
			-- end
		-- end
	-- end

	-- self.RagdollBoundsMin = mins - pos
	-- self.RagdollBoundsMax = maxs - pos
	-- self.RagdollBoundsFresh = true

-- end

-- if SERVER then

	-- function ENT:Think()

		-- if !self.DoneGeneratingPhysObjs then return end
		-- self:SetPos( self.PhysObjEnts[0]:GetPos() )

		-- if !self.RagdollBoundsFresh then self:GenerateRagdollBounds() end

		-- //Detect whether we're in the 3D skybox, and network that to clients to use in the Draw function because they can't detect it themselves
		-- //(sky_camera ent is serverside only and ent:IsEFlagSet(EFL_IN_SKYBOX) always returns false)
		-- local skycamera = ents.FindByClass("sky_camera")
		-- if istable(skycamera) then skycamera = skycamera[1] end
		-- if IsValid(skycamera) then
			-- local inskybox = self:TestPVS(skycamera)
			-- if self:GetNWBool("IsInSkybox") != inskybox then
				-- self:SetNWBool("IsInSkybox", inskybox)
			-- end
		-- end

		-- self:NextThink(CurTime())

	-- end

	-- //Make sure the physobjs are the correct distance from each other, so the ragdoll doesn't "stretch" and/or end up with physobjs in different places than they visually appear to be
	-- function ENT:CorrectPhysObjLocations()

		-- if !self.DoneGeneratingPhysObjs then return end

		-- for k, physent in pairs (self.PhysObjEnts) do
			-- local physobj = physent:GetPhysicsObject()
			-- if physent.PhysParent then
				-- local ourpos, _ = LocalToWorld(physent.PhysParentOffsetPos, Angle(0,0,0), physent.PhysParent:GetPos(), physent.PhysParent:GetAngles())
				-- local vel = physobj:GetVelocity()

				-- local mins, maxs = physobj:GetAABB()
				-- local size = maxs - mins
				-- local mult = 0.1

				-- //Give frozen physobjs a lot more leeway so they can stay in one spot
				-- if !physobj:IsMotionEnabled() and (!physent.StopMovingOnceFrozen or physent.StopMovingOnceFrozen == 0) then mult = 0.75 end
				
				-- if math.abs(physobj:GetPos():Distance(ourpos)) > ((size.x + size.y + size.z) / 3) * mult then
					-- physobj:SetPos(ourpos, true)
					-- physobj:SetVelocityInstantaneous(vel) //if we don't restore the velocity after moving the physobj then the ragdoll gets all floaty
				-- end

			-- end
		-- end

	-- end

-- end




-- duplicator.RegisterEntityClass( "prop_resizedragdoll_physparent", function( ply, data )
	-- local ent = ents.Create("prop_resizedragdoll_physparent")

	-- local OldBoneManip = data.BoneManip  //don't apply bone manips until after we've initialized the entity, otherwise it'll mess up the physbone offsets
	-- data.BoneManip = nil
	-- duplicator.DoGeneric(ent, data)

	-- //in multiplayer, physobj scale is clamped between 0.20 and 50; don't let them bypass this by loading an unclamped dupe from singleplayer
	-- if !game.SinglePlayer() then
		-- for num, scalevec in pairs (data.PhysObjScales) do
			-- data.PhysObjScales[num] = Vector( math.Clamp(scalevec.x, 0.20, 50), math.Clamp(scalevec.y, 0.20, 50), math.Clamp(scalevec.z, 0.20, 50) )
		-- end
	-- end
	-- ent.PhysObjScales = data.PhysObjScales
	-- ent.PhysObjMeshes = data.PhysObjMeshes
	-- //don't copy any of these values, they should be recreated from scratch when ent:Initialize() runs
	-- ent.ModelInfo = nil
	-- ent.PhysObjPhysBoneIDs = nil
	-- ent.PhysObjs = nil
	-- ent.PhysObjEnts = nil
	-- ent.ConstraintSystem = nil
	-- ent.DoneGeneratingPhysObjs = nil
	-- ent.PostInitializeFunction = nil
	-- ent.RagdollBoundsFresh = nil
	-- ent.RagdollBoundsMin = nil
	-- ent.RagdollBoundsMax = nil

	-- local sequence = ent:LookupSequence("ragdoll")
	-- if sequence != -1 then ent:SetSequence(sequence) ent:ResetSequence(sequence) end

	-- ent.PostInitializeFunction = function()
		-- if ( data.ColGroup ) then ent:SetCollisionGroup( data.ColGroup ) end
		-- duplicator.DoGenericPhysics(ent, ply, data)
		-- duplicator.DoBoneManipulator(ent, OldBoneManip)  //now it's safe to apply the bone manips
	-- end
	-- ent:Spawn()  //initialize the entity and have it create its physobjs

	-- return ent
-- end, "Data" )









































-- //FUNCTION REDIRECTS:
-- //Whenever something interacts with a resized ragdoll's parent ent or physobj ents, we need to trick the game into thinking it's just one entity with multiple physics objects, like a 
-- //regular ragdoll. This is mostly accomplished through a whole bunch of metatable stuff.

-- RagdollResizerDebugMsg("Creating function detours start")

-- local meta = FindMetaTable("Entity")
-- RagdollResizerDebugMsg('FindMetaTable("Entity") = ' .. tostring(meta)) //don't print the whole metatable, we just need to confirm that it exists and isn't nil

-- //Physobj retrieval functions
-- local old_GetPhysicsObject = meta.GetPhysicsObject
-- //RagdollResizerDebugMsg("meta.GetPhysicsObject = ", meta.GetPhysicsObject)
-- if old_GetPhysicsObject then
	-- //RagdollResizerDebugMsg('debug.getinfo(old_GetPhysicsObject, "S") = ', debug.getinfo(old_GetPhysicsObject, "S"))
	-- function meta.GetPhysicsObject(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") and ent.PhysObjs then
			-- local physobj = ent.PhysObjs[0]
			-- //MsgN("overridden GetPhysicsObject: " .. tostring(physobj))
			-- if physobj then return physobj else return NULL end
		-- else
			-- return old_GetPhysicsObject(ent, ...)
		-- end
	-- end
-- end

-- local old_GetPhysicsObjectNum = meta.GetPhysicsObjectNum
-- //RagdollResizerDebugMsg("meta.GetPhysicsObjectNum = ", meta.GetPhysicsObjectNum)
-- if old_GetPhysicsObjectNum then
	-- //RagdollResizerDebugMsg('debug.getinfo(old_GetPhysicsObjectNum, "S") = ', debug.getinfo(old_GetPhysicsObjectNum, "S"))
	-- function meta.GetPhysicsObjectNum(ent, num, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") and ent.PhysObjs then
			-- local physobj = ent.PhysObjs[num]
			-- //MsgN("overridden GetPhysicsObjectNum(" .. num .. "): " .. tostring(physobj))
			-- if physobj then return physobj else return ent.PhysObjs[0] end  //i really don't like this method, but some default gmod functions will error if we don't return a valid physobj here, and the ent probably shouldn't exist anyway if physobj 0 didn't generate
		-- else
			-- return old_GetPhysicsObjectNum(ent, num, ...)
		-- end
	-- end
-- end

-- local old_GetPhysicsObjectCount = meta.GetPhysicsObjectCount
-- //RagdollResizerDebugMsg("meta.GetPhysicsObjectCount = ", meta.GetPhysicsObjectCount)
-- if old_GetPhysicsObjectCount then
	-- //RagdollResizerDebugMsg('debug.getinfo(old_GetPhysicsObjectCount, "S") = ', debug.getinfo(old_GetPhysicsObjectCount, "S"))
	-- function meta.GetPhysicsObjectCount(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") and ent.PhysObjScales then
			-- //MsgN("overridden GetPhysicsObjectCount: " .. tostring(table.Count(ent.PhysObjScales)))
			-- return table.Count(ent.PhysObjScales)
		-- else
			-- return old_GetPhysicsObjectCount(ent, ...)
		-- end
	-- end
-- end




-- //GetMoveType - if we don't do this then most constraint tools won't work on us
-- local old_GetMoveType = meta.GetMoveType
-- if old_GetMoveType then
	-- function meta.GetMoveType(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") then
			-- return MOVETYPE_VPHYSICS
		-- else
			-- return old_GetMoveType(ent, ...)
		-- end
	-- end
-- end

-- //SetCollisionGroup - necessary for the nocollide tool to work
-- local old_SetCollisionGroup = meta.SetCollisionGroup
-- if old_SetCollisionGroup then
	-- function meta.SetCollisionGroup(ent, group, ...)
		-- old_SetCollisionGroup(ent, group, ...)

		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") then
			-- if ent.PhysObjEnts then
				-- for _, physobjent in pairs (ent.PhysObjEnts) do
					-- if IsValid(physobjent) then old_SetCollisionGroup(physobjent, group, ...) end
				-- end
			-- end
		-- end
	-- end
-- end

-- //GetCollisionBounds
-- local old_GetCollisionBounds = meta.GetCollisionBounds
-- if old_GetCollisionBounds then
	-- function meta.GetCollisionBounds(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") and (ent.RagdollBoundsMin and ent.RagdollBoundsMax) then
			-- return ent.RagdollBoundsMin, ent.RagdollBoundsMax
		-- else
			-- return old_GetCollisionBounds(ent, ...)
		-- end
	-- end
-- end

-- //OBBMins
-- local old_OBBMins = meta.OBBMins
-- if old_OBBMins then
	-- function meta.OBBMins(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") and (ent.RagdollBoundsMin and ent.RagdollBoundsMax) then
			-- return ent.RagdollBoundsMin
		-- else
			-- return old_OBBMins(ent, ...)
		-- end
	-- end
-- end

-- //OBBMaxs
-- local old_OBBMaxs = meta.OBBMaxs
-- if old_OBBMaxs then
	-- function meta.OBBMaxs(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") and (ent.RagdollBoundsMin and ent.RagdollBoundsMax) then
			-- return ent.RagdollBoundsMax
		-- else
			-- return old_OBBMaxs(ent, ...)
		-- end
	-- end
-- end

-- //OBBCenter
-- local old_OBBCenter = meta.OBBCenter
-- if old_OBBCenter then
	-- function meta.OBBCenter(ent, ...)
		-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") then
			-- return (ent.RagdollBoundsMin + ent.RagdollBoundsMax) / 2
		-- else
			-- return old_OBBCenter(ent, ...)
		-- end
	-- end
-- end

-- //GetClass - i should be ashamed of a solution this hacky; trick anything that interacts with us into thinking we're a prop_ragdoll 
-- //(we can still check if a prop_ragdoll is real or a prop_resizedragdoll_physparent by checking for ent.ClassOverride)
-- local old_GetClass = meta.GetClass
-- //RagdollResizerDebugMsg("meta.GetClass = ", meta.GetClass)
-- if old_GetClass then
	-- //RagdollResizerDebugMsg('debug.getinfo(old_GetClass, "S") = ', debug.getinfo(old_GetClass, "S"))
	-- function meta.GetClass(ent, ...)
		-- local class = old_GetClass(ent, ...)

		-- if class == "prop_resizedragdoll_physparent" then
			-- return "prop_ragdoll"
		-- else
			-- return class
		-- end
	-- end
-- end




-- //Traces - any trace that hits a physobj should be redirected to hit the parent entity instead
-- local old_TraceLine = util.TraceLine
-- RagdollResizerDebugMsg("util.TraceLine = ", util.TraceLine)
-- if old_TraceLine then
	-- RagdollResizerDebugMsg('debug.getinfo(old_TraceLine, "fS") = ', debug.getinfo(old_TraceLine, "fS"))
	-- function util.TraceLine(tracetab, ...)
		-- local trace = old_TraceLine(tracetab, ...)

		-- //print debug message whenever the trace hit a valid entity just so we know the detour is working
		-- if isentity(trace.Entity) and IsValid(trace.Entity) then
			-- RagdollResizerDebugMsg("TraceLine start")
			-- RagdollResizerDebugMsg("TraceLine: hit ent ", trace.Entity)
			-- RagdollResizerDebugMsg("TraceLine: trace.Entity:GetClass() = ", trace.Entity:GetClass())
		-- end

		-- //If we've hit a resized ragdoll physobj, then redirect the trace so it thinks it's hit the parent instead
		-- if isentity(trace.Entity) and IsValid(trace.Entity) and trace.Entity:GetClass() == "prop_resizedragdoll_physobj" then
			-- RagdollResizerDebugMsg("TraceLine: hit prop_resizedragdoll_physobj ent ", trace.Entity)
			-- //debug physobj redirect
			-- RagdollResizerDebugMsg("TraceLine: trace.Entity.PhysBoneNum = ", trace.Entity.PhysBoneNum)
			-- RagdollResizerDebugMsg("TraceLine: trace.PhysicsBone = ", trace.PhysicsBone)
			-- //debug entity redirect
			-- RagdollResizerDebugMsg("TraceLine: trace.Entity.RagdollParent = ", trace.Entity.RagdollParent)
			-- RagdollResizerDebugMsg("TraceLine: IsValid(trace.Entity.RagdollParent) = ", IsValid(trace.Entity.RagdollParent))
			-- if IsValid(trace.Entity.RagdollParent) then
				-- RagdollResizerDebugMsg("TraceLine: trace.Entity.RagdollParent:GetClass() = ", trace.Entity.RagdollParent:GetClass())
			-- end

			-- if trace.Entity.PhysBoneNum and trace.PhysicsBone then trace.PhysicsBone = trace.Entity.PhysBoneNum end
			-- if IsValid(trace.Entity.RagdollParent) then trace.Entity = trace.Entity.RagdollParent end
		-- end

		-- //print debug message whenever the trace hit a valid entity just so we know the detour is working
		-- if isentity(trace.Entity) and IsValid(trace.Entity) then
			-- RagdollResizerDebugMsg("TraceLine end")
		-- end

		-- return trace
	-- end
	-- RagdollResizerDebugMsg('debug.getinfo(util.TraceLine, "fS") = ', debug.getinfo(util.TraceLine, "fS"))
-- end




-- //Physgun halo effects - using the hooks instead won't work for these, unfortunately, it either won't render the halo at all, or still render the halo around the physobj ent
-- local old_DrawPhysgunBeam = GAMEMODE.DrawPhysgunBeam
-- if old_DrawPhysgunBeam then
	-- function GAMEMODE.DrawPhysgunBeam(self, ply, weapon, bOn, target, boneid, pos, ...)
		-- if isentity(target) and IsValid(target) and target:GetClass() == "prop_resizedragdoll_physobj" then
			-- if IsValid(target.RagdollParent) then target = target.RagdollParent end
		-- end
		-- return old_DrawPhysgunBeam(self, ply, weapon, bOn, target, boneid, pos, ...)
	-- end
-- end

-- local old_PlayerFrozeObject = GAMEMODE.PlayerFrozeObject
-- if old_PlayerFrozeObject then
	-- function GAMEMODE.PlayerFrozeObject(self, ply, entity, physobject, ...)
		-- if isentity(entity) and IsValid(entity) and entity:GetClass() == "prop_resizedragdoll_physobj" then
			-- if IsValid(entity.RagdollParent) then entity = entity.RagdollParent end
		-- end
		-- return old_PlayerFrozeObject(self, ply, entity, physobject, ...)
	-- end
-- end

-- local old_PlayerUnfrozeObject = GAMEMODE.PlayerUnfrozeObject
-- if old_PlayerUnfrozeObject then
	-- function GAMEMODE.PlayerUnfrozeObject(self, ply, entity, physobject, ...)
		-- if isentity(entity) and IsValid(entity) and entity:GetClass() == "prop_resizedragdoll_physobj" then
			-- if IsValid(entity.RagdollParent) then entity = entity.RagdollParent end
		-- end
		-- return old_PlayerUnfrozeObject(self, ply, entity, physobject, ...)
	-- end
-- end




-- //Serverside eye posing fix - since BuildBonePositions only runs clientside, the server still thinks the bones and attachments are floating there above the entity in a reference pose. 
-- //This means when the Eye Poser tool uses ent:GetAttachment( eyeattachment ) serverside, it gets the wrong pos/ang for the eye attachment and sets the eye target to a pos relative to 
-- //the wrong spot, resulting in the ragdoll looking in the wrong direction. Here we'll override ent:GetAttachment() to make it return the "actual" pos/ang for the eye attachment.
-- if SERVER then
	-- local old_GetAttachment = meta.GetAttachment
	-- if old_GetAttachment then
		-- function meta.GetAttachment(ent, attachmentId, ...)
			-- if isentity(ent) and IsValid(ent) and (ent:GetClass() == "prop_ragdoll" and ent.ClassOverride == "prop_resizedragdoll_physparent") then
				-- local eyeattachment = ent:LookupAttachment("eyes")
				-- if eyeattachment != 0 and attachmentId == eyeattachment then
					-- //First, retrieve the bone that the eye attachment is attached to. Gmod doesn't have a function for this, so we'll just have to search for a head
                                        -- //bone by looking at the bones' names, and assume the eye attachment is attached to that one.
                                        -- //(this method is terrible and will probably break with weird custom models, but there's no alternative)
					-- local function FindHeadBoneName()
						-- //First try some common names
						-- local result = ent:LookupBone("bip_head") or ent:LookupBone("ValveBiped.BipO1_Head1") or ent:LookupBone("ValveBiped.head") or nil
						-- if result then return result end
						-- //Common names didn't return anything, so search for the word "head" in all the bone names
						-- for i = 0, ent:GetBoneCount() - 1 do
							-- if string.find(string.lower(ent:GetBoneName(i)), "head", 1, true) then return i end
						-- end
					-- end

					-- local headbone = FindHeadBoneName()
					-- if headbone then
						-- //We're going to be using the head bone's physobj later to figure out where the attachment is actually supposed to be, so just in case the
						-- //head bone is actually just a child of the bone that owns the physobj (like fingers are to a hand bone), use that bone instead.
						-- local _physbone = ent:TranslateBoneToPhysBone(headbone)
						-- if _physbone and _physbone != -1 then _physbone = ent:TranslatePhysBoneToBone(_physbone) end
						-- if _physbone and _physbone != -1 and _physbone != headbone then headbone = _physbone end

						-- //Second, get the attachment's pos/ang offset from the head bone.
						-- local _headbone_ref = {}
						-- local _matr = ent:GetBoneMatrix(headbone)
						-- if _matr then
							-- _headbone_ref.Pos = _matr:GetTranslation()
							-- _headbone_ref.Ang = _matr:GetAngles()
						-- else
							-- _headbone_ref.Pos, _headbone_ref.Ang = ent:GetBonePosition(headbone)
						-- end
						-- local _attach_ref = old_GetAttachment(ent, attachmentId, ...) or {Ang = Angle(0,0,0), Pos = Vector(0,0,0)}
						-- local attach_offset_pos, attach_offset_ang = WorldToLocal(_attach_ref.Pos, _attach_ref.Ang, _headbone_ref.Pos, _headbone_ref.Ang)

						-- //Lastly, get the position of the head physobj and apply the offset(s) to it to get the "real" location of the eye attachment.
						-- local physnum = ent:TranslateBoneToPhysBone(headbone)
						-- local physent = ent.PhysObjs[physnum]
						-- if physent then  //sadly this won't work if the head physobj failed to generate (TODO?: add handling to use some parent physobj instead?)
							-- local physpos, physang = physent:GetPos(), physent:GetAngles()
							-- physpos, physang = LocalToWorld(attach_offset_pos * ent.PhysObjScales[physnum], attach_offset_ang, physpos, physang)

							-- return {Ang = physang, Pos = physpos}
						-- end
					-- end
				-- end
			-- end

			-- return old_GetAttachment(ent, attachmentId, ...)
		-- end
	-- end
-- end

-- RagdollResizerDebugMsg("Creating function detours end")