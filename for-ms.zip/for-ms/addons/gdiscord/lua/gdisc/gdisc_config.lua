GDiscord = {}

GDiscord.config = {
        ['discord_gateway_link'] = "wss://gateway.discord.gg/?v=9&encoding=json",
        ['discord_webhook'] = "https://discord.com/api/webhooks/1091196413079212142/FopHbOA_yJISzjTEVl5NCfpvEVBOuGe_sdID6RvsbdMu7lk2GzyWMDOSfk2HXKzTqsap",
        ['bot_token'] = "MTA5MTE5Njc5MzE3OTYwNzA0MA.GFnjWB.FV8zjw_xAL8hhII0ZKJRjwzTj1YDvmcOUr1tAU",
        ['channel_id'] = "1091196333592956938"
    }