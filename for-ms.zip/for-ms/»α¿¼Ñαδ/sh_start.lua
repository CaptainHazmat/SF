FACTION.name = "[Новенький]"
FACTION.desc = "[Человек, поступивший на работу.]"
FACTION.health = 100
FACTION.armor = 0		
FACTION.color = Color(255, 0, 0)
FACTION.isDefault = true
FACTION.isGloballyRecognized = false	
FACTION.ranktable = "RanksNEW"	
FACTION.models = {
"models/kuge/private military contractor/playermodels/pmc-1.mdl",
"models/kuge/private military contractor/playermodels/pmc_kidman.mdl",
}

FACTION_START = FACTION.index