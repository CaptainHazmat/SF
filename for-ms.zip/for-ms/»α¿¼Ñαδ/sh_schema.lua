﻿SCHEMA.name = "militaryrp"
SCHEMA.author = "Tium"
SCHEMA.desc = "Tium"

if (!serverguard) then return end
serverguard.plugin:Toggle("restrictions", false)

--------------------------------- фикс моделей---------------------------------

nut.anim.setModelClass("models/drem/cch/female_01.mdl", "player")
nut.anim.setModelClass("models/Humans/Group01/Female_01.mdl", "player")
--nut.anim.setModelClass("", "player")

----------------------------------модели покупаемые----------------------------------
SCHEMA.ExtraModel = {
	["male"] = {
		[1] = {
			model = "models/Kuge/Private Military Contractor/Playermodels/PMC-2_G3.mdl",
			canBuy = true,
			money = 7500
		},
		[2] = {
			model = "models/kuge/private military contractor/playermodels/pmc-1_g3.mdl",
			canBuy = true,
			money = 7500
		},
		[3] = {
			model = "models/ryse/motoess/sas-2.mdl",
			canBuy = true,
			money = 18000
		},
		[4] = {
			model = "models/ryse/motoess/sas-3.mdl",
			canBuy = true,
			money = 18000
		},
		[5] = {
			model = "models/ryse/motoess/sas-4.mdl",
			canBuy = true,
			money = 18000
		},
		[6] = {
			model = "models/Kuge/Private Military Contractor/Playermodels/PMC-3_G3.mdl",
			canBuy = true,
			money = 37500
		},
		[7] = {
			model = "models/Kuge/Private Military Contractor/Playermodels/PMC_KORD.mdl",
			canBuy = true,
			money = 75000
		},
		[8] = {
			model = "models/Kuge/Private Military Contractor/Playermodels/PMC_BDU.mdl",
			canBuy = true,
			money = 55000
		},
		[9] = {
			model = "models/player/w4ys3rs_garage/gru/gru_1_balaclava.mdl",
			canBuy = true,
			money = 0
		},
		[10] = {
			model = "models/arachnit/residentevil7/notahero/characters/umbrella_soldier/umbrella_soldier_player.mdl",
			canBuy = true,
			money = 75000
		},
		
	},
	["female"] = {
		[1] = {
			model = "models/kuge/private military contractor/playermodels/pmc_torres.mdl",
			canBuy = true,
			money = 37000
		},
		[2] = {
			model = "models/resident_evil/resistance/valerie/valerie.mdl",
			canBuy = true,
			money = 37000
		},
	},
}

SCHEMA.RanksData = {
	["RanksNEW"] ={
		ranks = { -- ранговая таблица
			[1] = "TR",
		},
		translate = { --- перевод звания
			[1] = "Стажер",
		},
		salary= { --- зарплата
			[1] = 50,
		},
		canup ={ --- до какого звания может повысить
			[1] = 0,
		},
	},

	["Ranksmain"] ={
		ranks = { -- ранговая таблица
			[1] = "NEW",
			[2] = "PVT",
			[3] = "PFC",
			[4] = "CPL",
			
			[5] = "SGT",
			[6] = "1SG",
			[7] = "SGM",
			[8] = "CAPT",
			[9] = "MAJ",
		},
		translate = { --- перевод звания
			[1] = "Наемник",
			[2] = "Рядовой",
			[3] = "Первый Рядовой",
			[4] = "Капрал",
			
			[5] = "Сержант",
			[6] = "Первый сержант",
			[7] = "Сержант-Майор",
			[8] = "Капитан",
			[9] = "Майор",
		},
		salary = { --- зарплата
			[1] = 625,
			[2] = 750,
			[3] = 850,
			[4] = 950,
			[5] = 1050,
			[6] = 1200,
			[7] = 1350,
			[8] = 1450,
			[9] = 1650,
		},
		canup ={ --- до какого звания может повысить
			[1] = 0,
			[2] = 0,
			[3] = 0,
			[4] = 3,
			[5] = 4,
			[6] = 4,
			[7] = 7,
			[8] = 7,
			[9] = 8,
		},
	},
	["RanksUSS"] ={
		ranks = { -- ранговая таблица
			[1] = "AG",
			[2] = "AG-S",
			[3] = "S-AG",
		},
		translate = { --- перевод звания
			[1] = "Агент ",
			[2] = "Агент-специалист",
			[3] = "Главный Агент",
		},
		salary= { --- зарплата
			[1] = 1000,
			[2] = 1250,
			[3] = 1875,
		},
		canup ={ --- до какого звания может повысить
			[1] = 0,
			[2] = 0,
			[3] = 2,
		},
	},
	["Ranksevent"] ={
		ranks = { -- ранговая таблица
			[1] = "UOP",
			[2] = "S-UOP",
		},
		translate = { --- перевод звания
			[1] = "Участник программы",
			[2] = "Глава программы",
		},
		salary = { --- зарплата
			[1] = 100,
			[2] = 100,
		},
		canup ={ --- до какого звания может повысить
			[1] = 0,
			[2] = 0,
		},
	},
}
nut.util.includeDir("hooks")

hook.Add("PrePACEditorOpen", "FlagCheck", function( client )
	if not client:getChar():hasFlags("P") then
		return false
	end
end)

if (CLIENT) then
	hook.Add( "SpawnMenuOpen", "FlagCheckPET", function()
		if not LocalPlayer():getChar():hasFlags("Y") and not IsValid(LocalPlayer():getChar()) then
			return false
		end
	end)
end
