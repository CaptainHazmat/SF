FACTION.name = "[U.B.C.S.]"
FACTION.desc = "[Человек, поступивший на работу.]"
FACTION.health = 100
FACTION.armor = 0		
FACTION.color = Color(0, 140, 0)
FACTION.isDefault = false
FACTION.isGloballyRecognized = false	
FACTION.ranktable = "Ranksmain"	-- какую систему рангов использует фракция
FACTION.typefact = "UBCS" -- для различия подразделений, если одиннаковые - то 1 кмд может повышать людей из разных фракций
FACTION.pay = 100
FACTION.payTime = 1800
FACTION.Gdisord = 1
FACTION.MaleModels = {
	[1] = "models/kuge/private military contractor/playermodels/pmc-1.mdl",
	[2] = "models/kuge/private military contractor/playermodels/pmc-1_casual.mdl",
	[3] = "models/Kuge/Private Military Contractor/Playermodels/PMC-2.mdl",
	[4] = "models/Kuge/Private Military Contractor/Playermodels/PMC-2_Casual.mdl",
	[5] = "models/Kuge/Private Military Contractor/Playermodels/PMC-3.mdl",
	[6] = "models/Kuge/Private Military Contractor/Playermodels/PMC-3_Casual.mdl",

	
}
FACTION.FemaleModels = {
	[1] = "models/kuge/private military contractor/playermodels/pmc_kidman.mdl",
	[2] = "models/kuge/private military contractor/playermodels/pmc_zoey.mdl",
	
}
FACTION.weapons = {"weapon_rdo_radio",}


function FACTION:onTransfered(client, oldFaction)
	if client:isFemale() then
		client:getChar():setModel(self.FemaleModels[1])
	else
		client:getChar():setModel(self.MaleModels[1])
	end
	if (oldFaction.typefact != self.typefact) then
		local char = client:getChar()
		char:setData("rank",1)
		client:setNetVar("rank",  1)
	end
end

FACTION_UBCS = FACTION.index
